(function() {
	angular
		.module('currentModel')
		.directive('legendArea', legendArea);

	/* @ngInject */
	legendArea.$inject = [];
	function legendArea() {
		function link(scope, element) {
			
			
		}

		// return the DDO
		return {
			link:link,
			controller: legendAreaController,
			bindToController: true,
			controllerAs: 'vm',
			scope: {
				chartData: '=',
				runId: "=",
				chartDataChanged: '=',
				getMinTick: "&",
				getMaxTick: "&",
				getTick: "&",
				displayChartLoader: '&'
			},
			replace:true,
			templateUrl: 'current_model/src/app/legend_area/legend-area.html'
		}
	}
	
	/* @ngInject */
	legendAreaController.$inject = ['$window', '$scope', 'currentModelService', 'THRESHOLD_MULTIPLIER'];
	function legendAreaController($window, $scope, currentModelService, THRESHOLD_MULTIPLIER) {
		var vm = this;
		
		vm.showBucketToolbar = false;
		vm.newBucketName = "New Bucket";
		vm.newBucketStartValue = "0.5";
		vm.newBucketEndValue = "0.5";
		vm.newBucketColor = "#000000";
		vm.newBucketThresholdErr = false;
		vm.legendHeight = ($("body").height() - 448) + 'px';
		vm.addBucketErrArr = ['Bucket name cannot be blank.', 'Start value cannot be higher than the end value.', 'Thresholds for a new Bucket may not cross the threshold of an existing Bucket. You can only add a new Bucket within an existing Bucket.'];
		vm.saveAlreadyClicked = false;
		
		//console.log("vm.getTick()", vm.getTick());
		vm.tickOptions = {
			format:"n4",
			decimals:4
		};
		
		$scope.$watch('vm.chartDataChanged', function (newValue, oldValue) {
    		if(newValue != oldValue){
    			vm.newBucketStartValue = vm.getMinTick();
    			vm.newBucketEndValue = vm.getMinTick() + vm.getTick();
    			vm.minTick = vm.getMinTick();
    			vm.maxTick = vm.getMaxTick();
    			vm.tick = vm.getTick();
    		}
    	});
		
		vm.addBucket = function(){
			var buckets = vm.chartData.buckets;
			var insertIndex = buckets.length;
			var newBucketObj = {"bucketName":vm.newBucketName,"lowThreshold":vm.newBucketStartValue * THRESHOLD_MULTIPLIER,"highThreshold":vm.newBucketEndValue * THRESHOLD_MULTIPLIER,"bucketColor":vm.newBucketColor};
			vm.displayChartLoader({val:true, msg:"Adding bucket"});
			currentModelService.addBucket(vm.runId, newBucketObj, vm.chartData.name)
				.then(function(response){
					vm.displayChartLoader({val:false, msg:""});
					if(response.status == 'duplicateBucketName'){
						vm.duplicateBucketName = true;
						//ALERTMESSAGE.open({type:"M", level:3, category:"information", content:"Can not add Bucket. Bucket with this name already exists.", title:"Information"});
					} else {
						vm.duplicateBucketName = false;
						vm.chartData.buckets = response;
					}
				});
		}
		
		vm.clearAddBucket = function(){
			vm.newBucketName = "New Bucket";
			vm.newBucketStartValue = "0.5";
			vm.newBucketEndValue = "0.5";
			vm.newBucketColor = "#00FF00";
		}
		
		vm.removeBucket = function(index, bucketId){
			if(vm.deleteAlreadyClicked[index]){
				vm.displayChartLoader({val:true, msg:"Deleting bucket"});
				currentModelService.removeBucket(vm.runId, bucketId, vm.chartData.name)
					.then(function(response){
						vm.displayChartLoader({val:false, msg:""});
						if(response.data == 'existsinbatchrule'){
							ALERTMESSAGE.open({type:"M", level:3, category:"information", content:"The selected bucket is included in a review batch rule. You must remove the bucket from all review batch rules before you can delete the bucket.", title:"Information"});
						} else {
							vm.chartData.buckets = response;
						}
					});
			}
			vm.deleteAlreadyClicked[index] = !vm.deleteAlreadyClicked[index];
		}
		
		vm.updateBucket = function(bucketId){
			var editBucketObj = {"bucketId":bucketId, "bucketName":vm.editBucketName,"lowThreshold":vm.editBucketStartValue * THRESHOLD_MULTIPLIER,"highThreshold":vm.editBucketEndValue * THRESHOLD_MULTIPLIER,"bucketColor":vm.editBucketColor};
			vm.displayChartLoader({val:true, msg:"Updating bucket"});
			currentModelService.updateBucket(editBucketObj, vm.chartData.name)
				.then(function(response){
					vm.displayChartLoader({val:false, msg:""});
					vm.chartData.buckets = response;
				});
		}
		
		vm.setEditBucket = function(bucket){
			vm.showUpdateBucketForm = true;
			vm.editBucketId = bucket.bucketID;
			vm.editBucketName = bucket.bucketName;
			vm.editBucketStartValue = bucket.lowThreshold / THRESHOLD_MULTIPLIER;
			vm.editBucketEndValue = bucket.highThreshold / THRESHOLD_MULTIPLIER;
			vm.editBucketColor = bucket.bucketColor;
		}
		
		vm.saveAllBuckets = function(){
			if(vm.saveAlreadyClicked){
				vm.displayChartLoader({val:true, msg:"Saving bucket state"});
				currentModelService.saveAllBuckets(vm.runId, vm.chartData.buckets, vm.chartData.name)
					.then(function(response){
						vm.displayChartLoader({val:false, msg:""});
						vm.chartData.buckets = response;
						ALERTMESSAGE.open({type:"M", level:3, category:"success", content:"Changes made to the buckets has been saved successfully. Current model has been refreshed.", title:"Success"});
					});
			}
			vm.saveAlreadyClicked = !vm.saveAlreadyClicked;
		}
		
		vm.applyLock = function(t){
			var action = t?'getLockForEdit':'removeLock';
			vm.displayChartLoader({val:true, msg:"Applying lock"});
			currentModelService.applyLock(action, vm.runId, vm.chartData.name)
				.then(function(response){
					vm.displayChartLoader({val:false, msg:""});
					vm.showBucketArea = '';
					if(response.status == 'lockapplied'){
						console.log("Lock applied");
						vm.showBucketToolbar = true;
					} else if(response.status == 'lockremoved'){
						console.log("Lock removed");
						vm.showBucketToolbar = false;
					} else {
						console.log("Editing is locked");
						ALERTMESSAGE.open({type:"M", level:3, category:"information", content:"Current model is locked by another user for editing.", title:"Locked"});
					}
				});
		}
		
		$scope.$watch('vm.showBucketArea', function (newValue, oldValue) {
        	if(newValue != oldValue){
    			if(newValue == 'add' || newValue == 'delete' || newValue == 'update'){
    				vm.legendHeight = ($("body").height() - 448) + 'px';
	    		}
    			else{
    				vm.legendHeight = ($("body").height() - 448) + 'px';
    			}
    		}
    	});
		
		$scope.$watch('vm.newBucketName', function (newValue, oldValue) {
        	if(newValue != oldValue){
        		vm.duplicateBucketName = false;
    		}
    	});
		
		
		$scope.$watch('vm.newBucketStartValue', function (newValue, oldValue) {
        	if(newValue != oldValue){
    			validateThresholdLimit();
    		}
    	});
		$scope.$watch('vm.newBucketEndValue', function (newValue, oldValue) {
        	if(newValue != oldValue){
    			validateThresholdLimit();
    		}
    	});
		function validateThresholdLimit(){
			//debugger;
			var thresholds = vm.chartData.bucketThresholds;
			
			for(var i=0; i<thresholds.length-1; i++){
				if(vm.newBucketStartValue >= thresholds[i]/THRESHOLD_MULTIPLIER && vm.newBucketEndValue <= thresholds[i+1]/THRESHOLD_MULTIPLIER){
					vm.newBucketThresholdErr = false;
					break;
				} else {
					vm.newBucketThresholdErr = true;
				}
			}
		}
		
		angular.element($window).bind('resize', function() {
			if(vm.showBucketArea == 'add' || vm.showBucketArea == 'delete' || vm.showBucketArea == 'update'){
				vm.legendHeight = ($("body").height() - 448) + 'px';
    		}
			else{
				vm.legendHeight = ($("body").height() - 448) + 'px';
			}
			
		});
	}
})();
