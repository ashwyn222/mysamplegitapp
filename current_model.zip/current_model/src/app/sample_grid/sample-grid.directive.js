(function() {
	angular
		.module('currentModel')
		.directive('sampleGrid', sampleGrid);

	/* @ngInject */
	sampleGrid.$inject = ['$http'];
	function sampleGrid($http){
		var directive = {
			link: link,
			controller: sampleGridController,
			controllerAs: 'vm',
			scope: {
				gadget : "=",
				gadgetData : "=",
				showSample : "=",
				updateShowSample : "&"
			},
			replace:true,
			bindToController: true,
			templateUrl: 'current_model/src/app/sample_grid/sample-grid.html'
		}
		
		return directive;
		
		function link(scope, element) {
			
		}
	}
	
	/* @ngInject */
	sampleGridController.$inject = ['$rootScope', '$scope', '$http', '$window', '$compile'];
	function sampleGridController($rootScope, $scope, $http, $window, $compile) {
		var vm = this;
		var isBatesColumn = false;
		vm.refreshingGrid = false;
		vm.noRecord = true;
		vm.allRowChkStatus = [];
		vm.checkAllPages = false;
		
		calculateGridContentHeight();
		columnDefinition = [{"field":"checkBox","title":"\u003cspan class\u003d\u0027ser-checkbox-off\u0027 ng-click\u003d\u0027vm.toggleAllRow($event)\u0027 id\u003d\u0027checkAll\u0027 /\u003e","template":$("#checkbox-column").html(),"width":"46px","baseWidth":"46px","minWidth":"46px","hidden":false,"sortable":true,"editable":true,"name":"CheckBox","type":"fixed","filterable":false},{"field":"docId","title":"Details","template":$("#details-column").html(),"width":"80px","baseWidth":"80px","minWidth":"80px","hidden":false,"sortable":true,"filter":{"extra":false,"ui":"docIdTextFilter"},"editable":true,"name":"Doc ID","type":"fixed","filterable":{"extra":false,"ui":"docIdTextFilter"}},{"field":"learningScore","title":"Score","width":"120px","baseWidth":"120px","minWidth":"60px","hidden":false,"sortable":true,"filter":{"extra":false,"ui":"simpleTextFilter"},"editable":true,"type":"fixed","filterable":{"extra":false,"ui":"simpleTextFilter"}},{"field":"reviewLock","title":" ","template":"\u003cdiv class\u003d\u0027reviewLock_#\u003d reviewLock # ser-lock\u0027\u003e\u003c/div\u003e","width":"30px","baseWidth":"30px","minWidth":"30px","hidden":false,"sortable":true,"editable":true,"name":"Review Lock","type":"fixed","filterable":false},{"field":"similarityScore","title":"S-Score","width":"85px","baseWidth":"85px","minWidth":"85px","hidden":true,"sortable":true,"editable":true,"name":"Similarity Score","type":"fixed","filterable":false},{"field":"defaultDate","title":"Profile Date","width":"105px","baseWidth":"105px","minWidth":"105px","hidden":false,"sortable":true,"filter":{"extra":true,"ui":"dateFilter"},"editable":true,"name":"Profile Date","type":"fixed","filterable":{"extra":true,"ui":"dateFilter"}},{"field":"profileSender","title":"Profile Sender","width":"30%","baseWidth":"30%","minWidth":"115px","hidden":false,"sortable":true,"filter":{"extra":false,"ui":"simpleTextFilter"},"editable":true,"name":"Profile Sender","type":"percentage","filterable":{"extra":false,"ui":"simpleTextFilter"}},{"field":"profileRecipients","title":"Profile Recipients","width":"","baseWidth":"","minWidth":"135px","hidden":false,"sortable":true,"filter":{"extra":false,"ui":"simpleTextFilter"},"editable":true,"name":"Profile Recipients","type":"available","filterable":{"extra":false,"ui":"simpleTextFilter"}},{"field":"subjectFileName","title":"Subject / Filename","width":"","baseWidth":"","minWidth":"140px","hidden":false,"sortable":true,"filter":{"extra":false,"ui":"simpleTextFilter"},"editable":true,"name":"Subject / Filename","type":"available","filterable":{"extra":false,"ui":"simpleTextFilter"}},{"field":"profileSubject","title":"Profile Subject","width":"","baseWidth":"","minWidth":"115px","hidden":true,"sortable":true,"filter":{"extra":false,"ui":"simpleTextFilter"},"editable":true,"name":"Profile Subject","type":"available","filterable":{"extra":false,"ui":"simpleTextFilter"}},{"field":"profileCc","title":"Profile CC","width":"95px","baseWidth":"95px","minWidth":"95px","hidden":true,"sortable":true,"filter":{"extra":false,"ui":"simpleTextFilter"},"editable":true,"name":"Profile CC","type":"fixed","filterable":{"extra":false,"ui":"simpleTextFilter"}},{"field":"profileBcc","title":"Profile Bcc","width":"95px","baseWidth":"95px","minWidth":"95px","hidden":true,"sortable":true,"filter":{"extra":false,"ui":"simpleTextFilter"},"editable":true,"name":"Profile Bcc","type":"fixed","filterable":{"extra":false,"ui":"simpleTextFilter"}},{"field":"profileDescription","title":"Profile Description","width":"140px","baseWidth":"140px","minWidth":"140px","hidden":true,"sortable":true,"filter":{"extra":false,"ui":"simpleTextFilter"},"editable":true,"name":"Profile Description","type":"fixed","filterable":{"extra":false,"ui":"simpleTextFilter"}},{"field":"key","title":"Key","width":"60px","baseWidth":"60px","minWidth":"60px","hidden":true,"sortable":true,"filter":{"extra":false,"ui":"reviewFilterKey","messages":{"info":"Apply Key Call:"}},"editable":true,"name":"Key","type":"fixed","filterable":{"extra":false,"ui":"reviewFilterKey","messages":{"info":"Apply Key Call:"}}},{"field":"keyBy","title":"Key By","width":"80px","baseWidth":"80px","minWidth":"80px","hidden":true,"sortable":true,"filter":{"extra":false,"ui":"keyByFilter","messages":{"info":"Apply Reviewer Filter:"}},"editable":true,"name":"Key By","type":"fixed","filterable":{"extra":false,"ui":"keyByFilter","messages":{"info":"Apply Reviewer Filter:"}}},{"field":"responsive","title":"Responsive","width":"105px","baseWidth":"105px","minWidth":"105px","hidden":true,"sortable":true,"filter":{"extra":false,"ui":"reviewFilterResponsive","messages":{"info":"Apply Responsive Call:"}},"editable":true,"name":"Responsive","type":"fixed","filterable":{"extra":false,"ui":"reviewFilterResponsive","messages":{"info":"Apply Responsive Call:"}}},{"field":"responsiveBy","title":"Responsive By","width":"120px","baseWidth":"120px","minWidth":"120px","hidden":true,"sortable":true,"filter":{"extra":false,"ui":"responsiveByFilter","messages":{"info":"Apply Reviewer Filter:"}},"editable":true,"name":"Responsive By","type":"fixed","filterable":{"extra":false,"ui":"responsiveByFilter","messages":{"info":"Apply Reviewer Filter:"}}},{"field":"responsiveDate","title":"Responsive Date","width":"130px","baseWidth":"130px","minWidth":"130px","hidden":true,"sortable":true,"filter":{"extra":true,"ui":"dateFilter"},"editable":true,"name":"Responsive Date","type":"fixed","filterable":{"extra":true,"ui":"dateFilter"}},{"field":"confidential","title":"Confidential","width":"105px","baseWidth":"105px","minWidth":"105px","hidden":true,"sortable":true,"filter":{"extra":false,"ui":"reviewFilterConfidential","messages":{"info":"Apply Confidential Call:"}},"editable":true,"name":"Confidential","type":"fixed","filterable":{"extra":false,"ui":"reviewFilterConfidential","messages":{"info":"Apply Confidential Call:"}}},{"field":"confidentialBy","title":"Confidential By","width":"120px","baseWidth":"120px","minWidth":"120px","hidden":true,"sortable":true,"filter":{"extra":false,"ui":"confidentialByFilter","messages":{"info":"Apply Reviewer Filter:"}},"editable":true,"name":"Confidential By","type":"fixed","filterable":{"extra":false,"ui":"confidentialByFilter","messages":{"info":"Apply Reviewer Filter:"}}},{"field":"confidentialDate","title":"Confidential Date","width":"135px","baseWidth":"135px","minWidth":"135px","hidden":true,"sortable":true,"filter":{"extra":true,"ui":"dateFilter"},"editable":true,"name":"Confidential Date","type":"fixed","filterable":{"extra":true,"ui":"dateFilter"}},{"field":"privilege","title":"Privilege","width":"90px","baseWidth":"90px","minWidth":"90px","hidden":true,"sortable":true,"filter":{"extra":false,"ui":"reviewFilterPrivilege","messages":{"info":"Apply Privilege Call:"}},"editable":true,"name":"Privilege","type":"fixed","filterable":{"extra":false,"ui":"reviewFilterPrivilege","messages":{"info":"Apply Privilege Call:"}}},{"field":"privilegeBy","title":"Privilege By","width":"105px","baseWidth":"105px","minWidth":"105px","hidden":true,"sortable":true,"filter":{"extra":false,"ui":"privilegeByFilter","messages":{"info":"Apply Reviewer Filter:"}},"editable":true,"name":"Privilege By","type":"fixed","filterable":{"extra":false,"ui":"privilegeByFilter","messages":{"info":"Apply Reviewer Filter:"}}},{"field":"privilegeDate","title":"Privilege Date","width":"115px","baseWidth":"115px","minWidth":"115px","hidden":true,"sortable":true,"filter":{"extra":true,"ui":"dateFilter"},"editable":true,"name":"Privilege Date","type":"fixed","filterable":{"extra":true,"ui":"dateFilter"}},{"field":"reviewStatus","title":"Review Status","width":"118px","baseWidth":"118px","minWidth":"118px","hidden":true,"sortable":true,"filter":{"extra":false,"ui":"reviewFilterReview","messages":{"info":"Apply Review Call:"}},"editable":true,"name":"Review Status","type":"fixed","filterable":{"extra":false,"ui":"reviewFilterReview","messages":{"info":"Apply Review Call:"}}},{"field":"reviewedBy","title":"Reviewer","width":"95px","baseWidth":"95px","minWidth":"95px","hidden":true,"sortable":true,"filter":{"extra":false,"ui":"reviewedByFilter","messages":{"info":"Apply Reviewer Filter:"}},"editable":true,"name":"Reviewed By","type":"fixed","filterable":{"extra":false,"ui":"reviewedByFilter","messages":{"info":"Apply Reviewer Filter:"}}},{"field":"reviewedDate","title":"Reviewed Date","width":"125px","baseWidth":"125px","minWidth":"125px","hidden":true,"sortable":true,"filter":{"extra":true,"ui":"dateFilter"},"editable":true,"name":"Reviewed Date","type":"fixed","filterable":{"extra":true,"ui":"dateFilter"}},{"field":"cascaded","title":"Cascaded","width":"95px","baseWidth":"95px","minWidth":"95px","hidden":true,"sortable":true,"editable":true,"name":"Cascaded","type":"fixed","filterable":false},{"field":"application","title":"Application","width":"100px","baseWidth":"100px","minWidth":"100px","hidden":true,"sortable":true,"filter":{"extra":false,"ui":"simpleTextFilter"},"editable":true,"name":"Application","type":"fixed","filterable":{"extra":false,"ui":"simpleTextFilter"}},{"field":"category","title":"Category","width":"90px","baseWidth":"90px","minWidth":"90px","hidden":true,"sortable":true,"filter":{"extra":false,"ui":"simpleTextFilter"},"editable":true,"name":"Category","type":"fixed","filterable":{"extra":false,"ui":"simpleTextFilter"}},{"field":"commentAuthor","title":"Comment Author","width":"130px","baseWidth":"130px","minWidth":"130px","hidden":true,"sortable":true,"filter":{"extra":false,"ui":"simpleTextFilter"},"editable":true,"name":"Comment Author","type":"fixed","filterable":{"extra":false,"ui":"simpleTextFilter"}},{"field":"company","title":"Company","width":"95px","baseWidth":"95px","minWidth":"95px","hidden":true,"sortable":true,"filter":{"extra":false,"ui":"simpleTextFilter"},"editable":true,"name":"Company","type":"fixed","filterable":{"extra":false,"ui":"simpleTextFilter"}},{"field":"custodian","title":"Custodian","width":"95px","baseWidth":"95px","minWidth":"95px","hidden":true,"sortable":true,"filter":{"extra":false,"ui":"simpleTextFilter"},"editable":true,"name":"Custodian","type":"fixed","filterable":{"extra":false,"ui":"simpleTextFilter"}},{"field":"globalCustodian","title":"Global Custodian","width":"182px","baseWidth":"182px","minWidth":"182px","hidden":true,"sortable":true,"filter":{"extra":false,"ui":"simpleTextFilter"},"editable":true,"name":"Global Custodian","type":"fixed","filterable":{"extra":false,"ui":"simpleTextFilter"}},{"field":"keywords","title":"Keywords","width":"95px","baseWidth":"95px","minWidth":"95px","hidden":true,"sortable":true,"filter":{"extra":false,"ui":"simpleTextFilter"},"editable":true,"name":"Keywords","type":"fixed","filterable":{"extra":false,"ui":"simpleTextFilter"}},{"field":"lastSavedBy","title":"Last Saved By","width":"120px","baseWidth":"120px","minWidth":"120px","hidden":true,"sortable":true,"filter":{"extra":false,"ui":"simpleTextFilter"},"editable":true,"name":"Last Saved By","type":"fixed","filterable":{"extra":false,"ui":"simpleTextFilter"}},{"field":"lastTenAuthor","title":"Last Ten Author","width":"125px","baseWidth":"125px","minWidth":"125px","hidden":true,"sortable":true,"filter":{"extra":false,"ui":"simpleTextFilter"},"editable":true,"name":"Last Ten Author","type":"fixed","filterable":{"extra":false,"ui":"simpleTextFilter"}},{"field":"mailbox","title":"Mailbox","width":"85px","baseWidth":"85px","minWidth":"85px","hidden":true,"sortable":true,"filter":{"extra":false,"ui":"simpleTextFilter"},"editable":true,"name":"Mailbox","type":"fixed","filterable":{"extra":false,"ui":"simpleTextFilter"}},{"field":"source","title":"Source","width":"85px","baseWidth":"85px","minWidth":"85px","hidden":true,"sortable":true,"filter":{"extra":false,"ui":"simpleTextFilter"},"editable":true,"name":"Source","type":"fixed","filterable":{"extra":false,"ui":"simpleTextFilter"}},{"field":"subject","title":"Subject","width":"80px","baseWidth":"80px","minWidth":"80px","hidden":true,"sortable":true,"filter":{"extra":false,"ui":"simpleTextFilter"},"editable":true,"name":"Subject","type":"fixed","filterable":{"extra":false,"ui":"simpleTextFilter"}},{"field":"summary","title":"Summary","width":"95px","baseWidth":"95px","minWidth":"95px","hidden":true,"sortable":true,"filter":{"extra":false,"ui":"simpleTextFilter"},"editable":true,"name":"Summary","type":"fixed","filterable":{"extra":false,"ui":"simpleTextFilter"}},{"field":"title","title":"Title","width":"65px","baseWidth":"65px","minWidth":"65px","hidden":true,"sortable":true,"filter":{"extra":false,"ui":"simpleTextFilter"},"editable":true,"name":"Title","type":"fixed","filterable":{"extra":false,"ui":"simpleTextFilter"}},{"field":"metadataAuthor","title":"Metadata Author","width":"","baseWidth":"","minWidth":"130px","hidden":true,"sortable":true,"filter":{"extra":false,"ui":"simpleTextFilter"},"editable":true,"name":"Metadata Author","type":"available","filterable":{"extra":false,"ui":"simpleTextFilter"}},{"field":"emailSenderAddress","title":"Email Sender Address","width":"160px","baseWidth":"160px","minWidth":"160px","hidden":true,"sortable":true,"filter":{"extra":false,"ui":"simpleTextFilter"},"editable":true,"name":"Email Sender Address","type":"fixed","filterable":{"extra":false,"ui":"simpleTextFilter"}},{"field":"emailSenderDomain","title":"Email Sender Domain","width":"160px","baseWidth":"160px","minWidth":"160px","hidden":true,"sortable":true,"filter":{"extra":false,"ui":"simpleTextFilter"},"editable":true,"name":"Email Sender Domain","type":"fixed","filterable":{"extra":false,"ui":"simpleTextFilter"}},{"field":"emailSenderFriendlyName","title":"Email Sender Friendly Name","width":"195px","baseWidth":"195px","minWidth":"195px","hidden":true,"sortable":true,"filter":{"extra":false,"ui":"simpleTextFilter"},"editable":true,"name":"Email Sender Friendly Name","type":"fixed","filterable":{"extra":false,"ui":"simpleTextFilter"}},{"field":"emailRecipientsAddress","title":"Email Recipients Address","width":"180px","baseWidth":"180px","minWidth":"180px","hidden":true,"sortable":true,"filter":{"extra":false,"ui":"simpleTextFilter"},"editable":true,"name":"Email Recipients Address","type":"fixed","filterable":{"extra":false,"ui":"simpleTextFilter"}},{"field":"emailRecipientsDomain","title":"Email Recipients Domain","width":"180px","baseWidth":"180px","minWidth":"180px","hidden":true,"sortable":true,"filter":{"extra":false,"ui":"simpleTextFilter"},"editable":true,"name":"Email Recipients Domain","type":"fixed","filterable":{"extra":false,"ui":"simpleTextFilter"}},{"field":"emailRecipientsFriendlyName","title":"Email Recipients FriendlyName","width":"210px","baseWidth":"210px","minWidth":"210px","hidden":true,"sortable":true,"filter":{"extra":false,"ui":"simpleTextFilter"},"editable":true,"name":"Email Recipients FriendlyName","type":"fixed","filterable":{"extra":false,"ui":"simpleTextFilter"}},{"field":"emailBccAddress","title":"Email Bcc Address","width":"142px","baseWidth":"142px","minWidth":"142px","hidden":true,"sortable":true,"filter":{"extra":false,"ui":"simpleTextFilter"},"editable":true,"name":"Email Bcc Address","type":"fixed","filterable":{"extra":false,"ui":"simpleTextFilter"}},{"field":"emailBccDomain","title":"Email Bcc Domain","width":"142px","baseWidth":"142px","minWidth":"142px","hidden":true,"sortable":true,"filter":{"extra":false,"ui":"simpleTextFilter"},"editable":true,"name":"Email Bcc Domain","type":"fixed","filterable":{"extra":false,"ui":"simpleTextFilter"}},{"field":"emailBccFriendlyName","title":"Email Bcc Friendly Name","width":"180px","baseWidth":"180px","minWidth":"180px","hidden":true,"sortable":true,"filter":{"extra":false,"ui":"simpleTextFilter"},"editable":true,"name":"Email Bcc Friendly Name","type":"fixed","filterable":{"extra":false,"ui":"simpleTextFilter"}},{"field":"emailCcAddress","title":"Email Cc Address","width":"140px","baseWidth":"140px","minWidth":"140px","hidden":true,"sortable":true,"filter":{"extra":false,"ui":"simpleTextFilter"},"editable":true,"name":"Email Cc Address","type":"fixed","filterable":{"extra":false,"ui":"simpleTextFilter"}},{"field":"emailCcDomain","title":"Email Cc Domain","width":"140px","baseWidth":"140px","minWidth":"140px","hidden":true,"sortable":true,"filter":{"extra":false,"ui":"simpleTextFilter"},"editable":true,"name":"Email Cc Domain","type":"fixed","filterable":{"extra":false,"ui":"simpleTextFilter"}},{"field":"emailCcFriendlyName","title":"Email Cc Friendly Name","width":"172px","baseWidth":"172px","minWidth":"172px","hidden":true,"sortable":true,"filter":{"extra":false,"ui":"simpleTextFilter"},"editable":true,"name":"Email Cc Friendly Name","type":"fixed","filterable":{"extra":false,"ui":"simpleTextFilter"}},{"field":"emailFolder","title":"Email Folder","width":"110px","baseWidth":"110px","minWidth":"110px","hidden":true,"sortable":true,"filter":{"extra":false,"ui":"simpleTextFilter"},"editable":true,"name":"Email Folder","type":"fixed","filterable":{"extra":false,"ui":"simpleTextFilter"}},{"field":"emailSubject","title":"Email Subject","width":"115px","baseWidth":"115px","minWidth":"115px","hidden":true,"sortable":true,"filter":{"extra":false,"ui":"simpleTextFilter"},"editable":true,"name":"Email Subject","type":"fixed","filterable":{"extra":false,"ui":"simpleTextFilter"}},{"field":"fileExtension","title":"File Extension","width":"115px","baseWidth":"115px","minWidth":"115px","hidden":true,"sortable":true,"filter":{"extra":false,"ui":"simpleTextFilter"},"editable":true,"name":"File Extension","type":"fixed","filterable":{"extra":false,"ui":"simpleTextFilter"}},{"field":"fileCreationDate","title":"File Creation Date","width":"140px","baseWidth":"140px","minWidth":"140px","hidden":true,"sortable":true,"filter":{"extra":true,"ui":"dateFilter"},"editable":true,"name":"File Creation Date","type":"fixed","filterable":{"extra":true,"ui":"dateFilter"}},{"field":"fileLastModifiiedDate","title":"File Last Modifiied Date","width":"170px","baseWidth":"170px","minWidth":"170px","hidden":true,"sortable":true,"filter":{"extra":true,"ui":"dateFilter"},"editable":true,"name":"File Last Modifiied Date","type":"fixed","filterable":{"extra":true,"ui":"dateFilter"}},{"field":"fileLastPrintedDate","title":"File Last Printed Date","width":"160px","baseWidth":"160px","minWidth":"160px","hidden":true,"sortable":true,"filter":{"extra":true,"ui":"dateFilter"},"editable":true,"name":"File Last Printed Date","type":"fixed","filterable":{"extra":true,"ui":"dateFilter"}},{"field":"emailLastModifiedDate","title":"Email Last Modified Date","width":"175px","baseWidth":"175px","minWidth":"175px","hidden":true,"sortable":true,"filter":{"extra":true,"ui":"dateFilter"},"editable":true,"name":"Email Last Modified Date","type":"fixed","filterable":{"extra":true,"ui":"dateFilter"}},{"field":"emailRecievedDate","title":"Email Recieved Date","width":"155px","baseWidth":"155px","minWidth":"155px","hidden":true,"sortable":true,"filter":{"extra":true,"ui":"dateFilter"},"editable":true,"name":"Email Recieved Date","type":"fixed","filterable":{"extra":true,"ui":"dateFilter"}},{"field":"emailSentDate","title":"Email Sent Date","width":"130px","baseWidth":"130px","minWidth":"130px","hidden":true,"sortable":true,"filter":{"extra":true,"ui":"dateFilter"},"editable":true,"name":"Email Sent Date","type":"fixed","filterable":{"extra":true,"ui":"dateFilter"}},{"field":"emailCreatedDate","title":"Email Created Date","width":"148px","baseWidth":"148px","minWidth":"148px","hidden":true,"sortable":true,"filter":{"extra":true,"ui":"dateFilter"},"editable":true,"name":"Email Created Date","type":"fixed","filterable":{"extra":true,"ui":"dateFilter"}},{"field":"systemCreationDate","title":"System Creation Date","width":"160px","baseWidth":"160px","minWidth":"160px","hidden":true,"sortable":true,"filter":{"extra":true,"ui":"dateFilter"},"editable":true,"name":"System Creation Date","type":"fixed","filterable":{"extra":true,"ui":"dateFilter"}},{"field":"systemLastAccessedDate","title":"System Last Accessed Date","width":"192px","baseWidth":"192px","minWidth":"192px","hidden":true,"sortable":true,"filter":{"extra":true,"ui":"dateFilter"},"editable":true,"name":"System Last Accessed Date","type":"fixed","filterable":{"extra":true,"ui":"dateFilter"}},{"field":"systemLastModifiedDate","title":"System Last Modified Date","width":"182px","baseWidth":"182px","minWidth":"182px","hidden":true,"sortable":true,"filter":{"extra":true,"ui":"dateFilter"},"editable":true,"name":"System Last Modified Date","type":"fixed","filterable":{"extra":true,"ui":"dateFilter"}},{"field":"archiveId","title":"Archive ID","width":"182px","baseWidth":"182px","minWidth":"182px","hidden":true,"sortable":true,"filter":{"extra":false,"ui":"simpleTextFilter"},"editable":true,"name":"Archive Id","type":"fixed","filterable":{"extra":false,"ui":"simpleTextFilter"}},{"field":"uuid","title":"UUID","width":"182px","baseWidth":"182px","minWidth":"182px","hidden":true,"sortable":true,"filter":{"extra":false,"ui":"simpleTextFilter"},"editable":true,"name":"UUID","type":"fixed","filterable":{"extra":false,"ui":"simpleTextFilter"}},{"field":"inventoryId","title":"Inventory ID ","width":"182px","baseWidth":"182px","minWidth":"182px","hidden":true,"sortable":true,"filter":{"extra":false,"ui":"simpleTextFilter"},"editable":true,"name":"Inventory Id","type":"fixed","filterable":{"extra":false,"ui":"simpleTextFilter"}},{"field":"familyGroupId","title":"Family Group ID ","width":"80px","baseWidth":"80px","minWidth":"80px","hidden":true,"sortable":true,"filter":{"extra":false,"ui":"simpleTextFilter"},"editable":true,"name":"Family Group ID","type":"fixed","filterable":{"extra":false,"ui":"simpleTextFilter"}},{"field":"custom_Date_2996","title":"Date New","width":"120px","baseWidth":"120px","minWidth":"60px","hidden":true,"sortable":true,"filter":{"extra":false,"ui":"dateFilter"},"editable":true,"type":"fixed","filterable":{"extra":false,"ui":"dateFilter"}},{"field":"custom_2998","title":"Double New","width":"120px","baseWidth":"120px","minWidth":"60px","hidden":true,"sortable":true,"filter":{"extra":false,"ui":"doubleFilter"},"editable":true,"type":"fixed","filterable":{"extra":false,"ui":"doubleFilter"}},{"field":"custom_2995","title":"Freeform New","width":"120px","baseWidth":"120px","minWidth":"60px","hidden":true,"sortable":true,"filter":{"extra":false,"ui":"simpleTextFilter"},"editable":true,"type":"fixed","filterable":{"extra":false,"ui":"simpleTextFilter"}},{"field":"custom_2997","title":"Numeric New","width":"120px","baseWidth":"120px","minWidth":"60px","hidden":true,"sortable":true,"filter":{"extra":false,"ui":"docIdTextFilter"},"editable":true,"type":"fixed","filterable":{"extra":false,"ui":"docIdTextFilter"}},{"field":"documentViewUrl","title":"Action","template":$("#action-column").html(),"width":"80px","baseWidth":"80px","minWidth":"80px","hidden":false,"sortable":false,"editable":true,"name":"Action","type":"fixed","filterable":false}];
		columnDefinition[2].hidden = true;
		//console.log(columnDefinition);
		var gridDataSource = new kendo.data.DataSource({
            error: function (error) {
				if(error.xhr != undefined && error.xhr.status == "400"){
                   vm.refreshingGrid = false;
                   ALERTMESSAGE.open({type:"S", level:4, category:"error", content:"Invalid grid request parameters.", title:"Bad request"});
                   return;
                }
				if(error.errors == "sessionTimeout"){
		        	window.location = "Timeout.jsp";
		        } else {
		        	vm.refreshingGrid = false;
		        	vm.noRecord = true;
		        }
		    },
        	transport: {
				read: {
					url: 'getDataGrid?action=datagrid',
					dataType: 'json',
					encoding: 'UTF-8',
					type: 'POST',
					cache: false
				},
                parameterMap : function(data, operation){

					//Show grid if hided on error
					$("#grid").show();
			    	$("#noresult").hide();
			    	
					if(!pagerClicked){
						//if(!filterCleared) showGridLoadAnimation();
						selectedRows = new Array();
		            	checkAllPages = new Array();
					}
					var selectedColumns;
					if(data.filter != undefined) {
						if(data.sort != undefined && data.sort[0].field == "similarityScore") data.sort = undefined;
						isSimilarityCall = false; simColumnApplied = false; dataChanged = true;
						if(data.filter.filters.length>1){// update or remove existing filter after applying new filter
							if(data.filter.filters[data.filter.filters.length-1].filters){
								var innerlen = data.filter.filters[data.filter.filters.length-1].filters.length;
								var firstFilter = data.filter.filters[data.filter.filters.length-1].filters[innerlen-2];
								var secondFilter = data.filter.filters[data.filter.filters.length-1].filters[innerlen-1];
								data.filter.filters = [];
								data.filter.filters[0] = firstFilter;
								data.filter.filters[1] = secondFilter;
								data.filter.filters.length=2;
							}else if(data.filter.filters[data.filter.filters.length-1].field.indexOf("Date")==-1 && !isBatesColumn){
								var latestFilter = data.filter.filters[data.filter.filters.length-1];
								data.filter.filters = [];
								data.filter.filters[0] = latestFilter;
								data.filter.filters.length=1;
							}
						}
						selectedColumns = getSelectedColumns();
					}
					//Current Selected columns by User
					if(appliedSelectedColumns != "" && appliedSelectedColumns != null && appliedSelectedColumns != undefined) 
						selectedColumns = appliedSelectedColumns;

					if(data.sort!= undefined && !pagerClicked){ //Reset page to first on each sort
						/*data.page=1;*/
						//data.skip=0;
						//sortApplied = true;
						if(!isSimilarityCall && data.sort[0].field == "similarityScore") {//if similarity doesn't exists remove sort of same column
							data.sort = undefined;
							sortApplied = false;
						}
					}
					if(pagerClicked && data.sort!= undefined){
						if(!isSimilarityCall && data.sort[0].field == "similarityScore") {//if similarity doesn't exists remove sort of same column
							data.sort = undefined;
							sortApplied = false;
						}
					}
					
					if(data.filter != undefined && data.filter.filters[0].field == "responsive"){
						var fieldName = data.filter.filters[0].field;
						data.filter.filters = [];
						data.filter.filters = [{"field":fieldName,"operator":"eq","value":responsiveVals.toString().replace(/,/g, ';')}]
					}
					if(data.filter != undefined && data.filter.filters[0].field == "privilege"){
						var fieldName = data.filter.filters[0].field;
						data.filter.filters = [];
						data.filter.filters = [{"field":fieldName,"operator":"eq","value":privilegeVals.toString().replace(/,/g, ';')}]
					}
					if(data.filter != undefined && data.filter.filters[0].field == "confidential"){
						var fieldName = data.filter.filters[0].field;
						data.filter.filters = [];
						data.filter.filters = [{"field":fieldName,"operator":"eq","value":confidentialVals.toString().replace(/,/g, ';')}]
					}
					if(data.filter != undefined && data.filter.filters[0].field == "reviewStatus"){
						var fieldName = data.filter.filters[0].field;
						data.filter.filters = [];
						data.filter.filters = [{"field":fieldName,"operator":"eq","value":reviewstatusVals.toString().replace(/,/g, ';')}]
					}
					//Custom Filter
					if(data.filter != undefined && data.filter.filters[0].field.indexOf("custom_")!=-1 && isCustomMultiSelect){
						var fieldName = data.filter.filters[0].field;
						data.filter.filters = [];
						data.filter.filters = [{"field":fieldName,"operator":"eq","value":$("#"+fieldName).val().toString().replace(/,/g, ';')}]
					}
					//Bates Filter
					if(isBatesColumn && data.filter != undefined && data.filter.filters[0] != undefined && data.filter.filters[0].field.indexOf("docId")!= -1){
							var fieldName = data.filter.filters[0].field;
							if(data.filter.filters[0] != null && data.filter.filters[0].value) {
								$(".prefix").val(data.filter.filters[0].value);
							}
							if(data.filter.filters[1] != null && data.filter.filters[1].value) {
								$(".number").val(data.filter.filters[1].value);
							}
							data.filter.filters = [];
							data.filter.filters = [{"field":fieldName,"operator":"prefix","value":$(".prefix").val()},{"field":fieldName,"operator":"number","value":$(".number").val()},{"field":fieldName,"operator":"suffix","value":$(".suffix").val()}]
					}
					//Custom filter values for Date Filter, Review Multiselect Filters
					if((data.filter != undefined && data.filter.filters[0] != undefined && data.filter.filters[0].field.indexOf("Date") != -1)  || (data.filter != undefined && data.filter.filters[1] != undefined && data.filter.filters[1].field.indexOf("Date") != -1)){
						/*if(data.filter.filters[0] != undefined && data.filter.filters[0].value == ""){
							data.filter.filters[0].operator = "fromDt";
							data.filter.filters[0].value = "";
						}
						if(data.filter.filters[1] != undefined && data.filter.filters[1].value ==""){
							data.filter.filters[1].operator = "toDt";
							data.filter.filters[1].value = "";
						}*/
						var toDateFil, emptyArr = false;
						if(data.filter.filters[0] != undefined && data.filter.filters[0].value != ""){
							var fromDateString = data.filter.filters[0].value;
							var operatorString = "fromDt";
							if(isFromDate) operatorString = "fromDt";
							if(!isFromDate && isToDate) operatorString = "toDt";
							data.filter.filters[0].operator = operatorString;
							var str = kendo.toString(new Date(fromDateString), 'MM-dd-yyyy');
							if(str.indexOf("NaN") == -1)
								data.filter.filters[0].value = kendo.toString(new Date(fromDateString), 'MM-dd-yyyy');
							else{
								toDateFil = data.filter.filters[1];
								data.filter.filters = [];
								emptyArr = true;
							}
						}
						if(emptyArr){
							if(toDateFil != undefined && toDateFil.value !=""){
								var toDateString = toDateFil.value;
								toDateFil.operator = "toDt";
								toDateFil.value = kendo.toString(new Date(toDateString), 'MM-dd-yyyy');
								data.filter.filters[0] = toDateFil;
							}	
						}else{
							if(data.filter.filters[1] != undefined && data.filter.filters[1].value !=""){
								var toDateString = data.filter.filters[1].value;
								data.filter.filters[1].operator = "toDt";
								data.filter.filters[1].value = kendo.toString(new Date(toDateString), 'MM-dd-yyyy');
							}
						}
					}
					//console.log(JSON.stringify(data) + ":FINAL DATA SENDING")
					return "parameters="+encodeURIComponent(kendo.stringify(data))+"&selectedColumns="+encodeURIComponent(selectedColumns);
				
                	
                	//return "parameters="+encodeURIComponent(kendo.stringify(data));
                	
				}
			},
			schema : {
				data : "records",
				total : "totalRecords",
				errors: "Errors"
			},
			pageSize: defaultPageSize,
            serverPaging : true,
            serverSorting : true,
            serverFiltering: true
        });
        
        vm.gridOptions = {
	        autoBind:false,
            dataSource: gridDataSource,
            resizable: true,
            columnMenu : true,
            toolbar: kendo.template($("#sample-grid-toolbar").html()),
            pageable: {
    			input: true,
    			numeric: false,
    			pageSize: defaultPageSize,
    			messages: {
    				display: "{2:n0} - Documents found, displaying {0} to {1}",
    				empty: "",
    				itemsPerPage: "",
    				first: "First page",
    				last: "Last page",
    				next: "Next page",
    				previous: "Previous page"
    			}
    		},
            columns: columnDefinition,
            columnMenuInit: function (e) {
		        if(e.field == "checkBox") {
		        	var itemHtml = "<li class='k-item k-state-default' role='menuitem' ng-click='vm.checkAllPages = true'><span ng-class=\"{true:'ser-checkbox-on', false:'ser-checkbox-off', '':'ser-checkbox-off', undefined:'ser-checkbox-off'}[vm.checkAllPages]\"></span><span class='k-link'>Check On Every Page</span></li>" +
        			"<li class='k-item k-state-default' role='menuitem' ng-click='vm.checkAllPages = false'><span ng-class=\"{true:'ser-checkbox-on', false:'ser-checkbox-off', '':'ser-checkbox-off', undefined:'ser-checkbox-off'}[vm.checkAllPages]\"></span><span class='k-link'>Check On Current Page</span></li>";
		        	
		        	$(e.container).find("ul").html($compile(itemHtml)($scope));
		        } else {
		        	$(e.container).find("ul").html("");
		        }
			},
            dataBound: function(e){
            	vm.refreshingGrid = false;
            	vm.noRecord = false;
            	$scope.$apply();
            	$("#sample-grid + .refresh-shield").click();
            	vm.restoreCheckRows();
            }
    	};
        
        function parseJsMethods(columnDefinition){
        	if(columnDefinition != null){
        		for (var i = 0, len = columnDefinition.length; i < len; ++i) {
        			if(columnDefinition[i].hasOwnProperty('filter')){
        				if(columnDefinition[i].filter.ui != undefined && columnDefinition[i].filter.ui.indexOf("$.proxy") != -1){
        				//if($.isFunction(columnDefinition[i].filter.ui)){
        					columnDefinition[i].filter.ui = eval(columnDefinition[i].filter.ui);
        				}else{
        					var fn = window[columnDefinition[i].filter.ui];
        					columnDefinition[i].filter.ui = fn;
        				}
        			}
        			if(columnDefinition[i].hasOwnProperty('filterable')){
        				if(columnDefinition[i].filterable.ui != undefined && columnDefinition[i].filterable.ui.indexOf("$.proxy") != -1){
        				//if($.isFunction(columnDefinition[i].filterable.ui)){
        					columnDefinition[i].filterable.ui =  eval(columnDefinition[i].filterable.ui);
        				}else{
        					var fn = window[columnDefinition[i].filterable.ui];
        					columnDefinition[i].filterable.ui = fn;
        				}
        			}
        		 }
        	}
        }
        
        vm.callBatchAssign = function(){
        	//debugger;
        	var dataItems = getCheckedDataItems();
        	if(dataItems.length == 0){
        		ALERTMESSAGE.open({type:"S", level:4, category:"warning", content:"Please select the records you want to include for batch assign.", title:"Confirmation"});
        	} else {
        		console.log("valid batch assign");
        		DIALOG.open({
        		      type: 'XL',
        		      level: 2,
        		      loading: 'false',
        		      title: 'Assign Batch',
        		      path: 'GetBatchAssignWindow.do?batchAction=Assign&batchDocs='+dataItems+'&checkAll='+vm.checkAllPages+'&gridType=&rnd='+Math.random()
		        });
        	}
        }
        function getCheckedDataItems(){
        	var checkedItems = [];
        	for(let key in vm.allRowChkStatus){
				if(vm.allRowChkStatus.hasOwnProperty(key) && vm.allRowChkStatus[key]){
        			checkedItems.push(key);
        		}
			}
        	return checkedItems;
        }
        vm.setCheckStatus = function(dataItem){
        	//debugger;
        	dataItem.checkbox = !dataItem.checkbox;
    		vm.allRowChkStatus[dataItem.docId] = dataItem.checkbox;
			//console.log("All rows", vm.allRowChkStatus);
        }
        
        vm.toggleAllRow = function(e){
        	var element = $(e.currentTarget);
        	var checked = false;
        	if(element.hasClass("ser-checkbox-on")) {
				$(element).removeClass("ser-checkbox-on").addClass("ser-checkbox-off");
			} else {
				$(element).removeClass("ser-checkbox-off").addClass("ser-checkbox-on");
				checked = true;
			}
			$.grep(gridDataSource.data(), function(d) {
    			d.checkbox = checked;
    			vm.allRowChkStatus[d.docId] = d.checkbox;
        	});
        }
        
        vm.restoreCheckRows = function(){
        	if(vm.checkAllPages){
        		$.grep(gridDataSource.data(), function(d) {
        			d.checkbox = true;
	        		if(vm.allRowChkStatus[d.docId] == false){
	        			console.log(d.docId +" updated true");
	        			d.checkbox = false;
	        		}
	        	});
        	}
        	$.grep(gridDataSource.data(), function(d) {
        		if(vm.allRowChkStatus[d.docId]){
        			console.log(d.docId +" updated true");
        			d.checkbox = true;
        		}
        	});
        	//console.log(gridDataSource.data());
        	$scope.$apply();
        }
        
        $rootScope.$on('UPDATE_DOCUMENT_GRID', function(e){
        	vm.grid.dataSource.read();
    	});
        
        function calculateGridContentHeight() {
            vm.gridContentHeight = $(".dashboard-panel").height() - 88;
        }

        vm.backToResult = function(){
        	console.log("btr called");
        	vm.updateShowSample(false);
        }
        
        
        $scope.$watch('vm.showSample', function (newValue, oldValue) {
    		if(newValue != oldValue && newValue){
    			vm.refreshingGrid = true;
				vm.noRecord = false;
    			vm.grid.dataSource.read();
    		}
    	});
		
        function debounce(func, wait, immediate) {
        	var timeout;
        	return function() {
        		var context = this, args = arguments;
        		var later = function() {
        			timeout = null;
        			if (!immediate) func.apply(context, args);
        		};
        		var callNow = immediate && !timeout;
        		clearTimeout(timeout);
        		timeout = setTimeout(later, wait);
        		if (callNow) func.apply(context, args);
        	};
        };
        
        var debouncer = debounce(function() {
        	calculateGridContentHeight();
        }, 200);

        angular.element($window).bind('resize', function() {
        	debouncer();
        });
	}
})();
