(function() {
	angular
		.module('currentModel')
		.directive('histogram', histogram);

	/* @ngInject */
	function histogram(){
		function link(scope, element) {

		}

		return {
			link: link,
			controller: histogramController,
			controllerAs: 'vm',
			scope: {
				gadget : "=",
				gadgetData : "=",
				runId: "="
			},
			replace:true,
			bindToController: true,
			templateUrl: 'current_model/src/app/histogram/histogram.html'
		}
	}
	
	/* @ngInject */
	histogramController.$inject = ['$scope', '$http', '$q', 'currentModelService'];
	function histogramController($scope, $http, $q, currentModelService) {
		var vm = this;
		vm.showChartArea = true;
		vm.resizeMode = "FixedResizer";
		vm.selectedChartType = "all";
		vm.chartData = new Array(3);
		vm.showInitialChartLoader = true;
		vm.loadingMsg = "Loading All";
		
		vm.tick = 0.05;
		vm.minTick = 0;
		vm.maxTick = 1;
		vm.chartDataChanged = false;
		
		vm.getMinTick = function(){
			return vm.minTick;
		}
		vm.setMinTick = function(t){
			vm.minTick = t.val;
		}
		vm.getMaxTick = function(){
			return vm.maxTick;
		}
		vm.setMaxTick = function(t){
			vm.maxTick = t.val;
		}
		vm.getTick = function(){
			return vm.tick;
		}
		vm.setTick = function(t){
			vm.tick = t.val;
		}
		
		vm.displayChartLoader = function(flag){
			vm.showInitialChartLoader = flag.val;
			vm.loadingMsg = flag.msg;
		}
		
		init();
		function init() {
			vm.displayChartLoader({val:true, msg:"Loading All"});
			currentModelService.getChartData(vm.chartData.name, vm.runId, 'loadCurrentModel', 0, 1)
				.then(function(data){
					vm.displayChartLoader({val:false, msg:""});
					vm.chartData[1] = data;
					vm.chartDataChanged = true;
				});
		}
		

		$scope.$watch('vm.selectedChartType', function (newValue, oldValue) {
    		if(newValue != oldValue){
    			if(newValue == 'all'){
    				vm.chartData[1] = [];
    				vm.displayChartLoader({val:true, msg:"Loading All"});
    				currentModelService.getChartData(vm.chartData.name, vm.runId, 'loadCurrentModel', 0, 1)
	    				.then(function(data){
	    					vm.displayChartLoader({val:false, msg:""});
	    					vm.chartData[1] = data;
	    					vm.chartDataChanged = true;
	    				});
    				
    			} else if(newValue == 'responsive'){
    				vm.chartData[0] = [];
    				vm.displayChartLoader({val:true, msg:"Loading Predicted Responsive"});
    				currentModelService.getChartData(vm.chartData.name, vm.runId, 'loadCurrentModel', 0, 0.5)
	    				.then(function(data){
	    					vm.displayChartLoader({val:false, msg:""});
	    					vm.chartData[0] = data;
	    					vm.chartDataChanged = true;
	    				});
    			} else if(newValue == 'nonresponsive'){
    				vm.chartData[2] = [];
    				vm.displayChartLoader({val:true, msg:"Loading Predicted Non-Responsive"});
    				currentModelService.getChartData(vm.chartData.name, vm.runId, 'loadCurrentModel', 0.5, 1)
	    				.then(function(data){
	    					vm.displayChartLoader({val:false, msg:""});
	    					vm.chartData[2] = data;
	    					vm.chartDataChanged = true;
	    				});
    			}
    		}
    	});
	}
})();
