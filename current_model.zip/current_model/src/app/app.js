(function() {
	'use strict';	
	angular
	.module('currentModel', ['kendo.directives', 'networkResponseChecker', 'tooltipApp'/*, 'ngAnimate'*/])
	.constant('THRESHOLD_MULTIPLIER', 10000);
})();