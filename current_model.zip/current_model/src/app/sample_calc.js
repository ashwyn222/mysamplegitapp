var normalSampleValsChangeFlag = false;
var bayesianSampleValsChangeFlag = false;
userSpecifiedValueApply = false;
var manualDocsFlag = false;

function showSampleForm(text) {
	$("#ErrorBox").html('');
	$(".sampleTypeSection").find("input[type=radio]").prop("checked", false);
	$(".sampleTypeSection").find("label div.checkradios-radio").removeClass("ser-radio-on").addClass("ser-radio-off");
	if(text == "manual") {
		$("#manualType").prop("checked", true);
		$("#manualType").parent().addClass("ser-radio-on");
		$("#dialog1").removeClass("Normal Bayesian").addClass("Manual");
		$("#manualContentArea").fadeIn();
		$("#normalContentArea, #bayesianContentArea").hide();
		$('#sampleTypeObj').val('MANUAL');
	}
	else if(text == "normal") {
		$("#normalType").prop("checked", true);
		$("#normalType").parent().addClass("ser-radio-on");
		$("#dialog1").removeClass("Manual Bayesian").addClass("Normal");
		$("#normalContentArea").fadeIn();
		$("#manualContentArea, #bayesianContentArea").hide();
		$('#sampleTypeObj').val('NORMAL_DISTRIBUTION');
	}
	else if(text == "bayesian") {
		$("#bayesianType").prop("checked", true);
		$("#bayesianType").parent().addClass("ser-radio-on");
		$("#dialog1").removeClass("Manual Normal").addClass("Bayesian");
		$("#bayesianContentArea").fadeIn();
		$("#normalContentArea, #manualContentArea").hide();
		$('#sampleTypeObj').val('BAYESIAN');
	}
	changeDialogType("", "", "dialog1");
}


//for audited sample document starts
function openAuditedSampleBox() {
$('#dialog1').removeClass('Manual Bayesian').addClass('Normal');
changeDialogType('', '', 'dialog1');
if ($('#auditedSampleId').closest('div').hasClass('ser-checkbox-on')) {
 /*if($("#auditedSampleId").is(":checked")){*/
 $('#sampleForms, #sampleFormBtn').hide();
 $('#sampleTypeForm, #sampleTypeFormBtn').fadeIn();
}

// for lock sample document
if (
 $('#lockSampleDocumentObj').attr('value') != null &&
 $('#lockSampleDocumentObj').attr('value') == 'true'
) {
 /*$('#lockSampleDocument').attr('checked','checked');*/
 $('#lockSampleDocument')
   .closest('div')
   .addClass('ser-checkbox-on checked')
   .removeClass('ser-checkbox-off unchecked');
 $('#lockSampleDocument').prop('checked', true);
 $('#locksampleDocumentInnerView').show();
} else {
 $('#locksampleDocumentInnerView').hide();
 $('#lockSampleDocument')
   .closest('div')
   .removeClass('ser-checkbox-on checked')
   .addClass('ser-checkbox-off unchecked');
 $('#lockSampleDocument').prop('checked', false);
 /*$('#lockSampleDocument').removeAttr('checked');*/
}
}

function openLockSampleDocumentDiv() {
$('#lockSampleDocument')
 .closest('div')
 .toggleClass('ser-checkbox-on ser-checkbox-off');
$('#lockSampleDocument').closest('div').toggleClass('checked unchecked');
if ($('#lockSampleDocument').closest('div').hasClass('ser-checkbox-on')) {
 $('#locksampleDocumentInnerView').show();
 $('#lockSampleDocumentObj').attr('value', true);
 $('#lockSampleDocument').attr('value', false);
 $('#lockSampleDocument').prop('checked', false);
} else {
 $('#locksampleDocumentInnerView').hide();
 $('#lockSampleDocumentObj').attr('value', false);
 $('#lockSampleDocument').attr('value', true);
 $('#lockSampleDocument').prop('checked', true);
}
}

function cancelWhileManagedSample() {
sampleNameIsEmpty = false;
$('#ErrorBox').html('');
if ($('#manualType').is(':checked')) {
 $('#dialog1').removeClass('Normal Bayesian').addClass('Manual');
} else if ($('#normalType').is(':checked')) {
 $('#dialog1').removeClass('Manual Bayesian').addClass('Normal');
} else if ($('#bayesianType').is(':checked')) {
 $('#dialog1').removeClass('Manual Normal').addClass('Bayesian');
}
changeDialogType('', '', 'dialog1');
changeHeading('Sample Calculator', 'dialog1');
$('#sampleForms, #sampleFormBtn').fadeIn();
$('#sampleTypeForm, #sampleTypeFormBtn').hide();
}

function validateSampleTypeForm() {
var err = false;
if ($.trim($('#sampleNameTxt').val()) == '') {
 err = true;
 $('#sampleTypeForm')
   .find('#sampleNameTxt')
   .next('.errEx')
   .show()
   .children('.errtooltipR')
   .text('Sample name cannot be blank.');
} else {
 $('#sampleTypeForm').find('#sampleNameTxt').next('.errEx').hide();
}

if (
 $('#lockSampleDocument').closest('div').hasClass('ser-checkbox-on') &&
 $('#reviewStatusRecordListID').val() == ''
) {
 err = true;
 $('#reviewedCodeParent')
   .find('.errEx')
   .show()
   .children('.errtooltip')
   .text('Please select review status.');
} else {
 $('#reviewedCodeParent').find('.errEx').hide();
}

if (err == true) {
 return;
} else {
 sendAuditedSampleRequest();
}
}

var sampleNameIsEmpty = false;
function sendAuditedSampleRequest() {
sampleNameIsEmpty = true;
normalSampleValsChangeFlag = false;
bayesianSampleValsChangeFlag = false;
userSpecifiedValueApply = false;
setBayesianPriorMeanValue();
//$.fn.showData('GetSampleCalculator.do?action=createSample', '#SampleCalculatorForm');
$.ajax({
 type: 'POST',
 url: 'GetSampleCalculator.do?action=createSample&fromAjax=true',
 cache: false,
 data: $('#SampleCalculatorForm').serialize(),
 beforeSend: function() {
   $.fn.loadingAnimation({ display: 'open', msg: 'Creating Sample...' });
 },
 success: function(resp) {
   $.fn.loadingAnimation({ display: 'close' });
   if ($.trim(resp) == 'success') {
     $('#dialogClose1').click();
     ALERTMESSAGE.open({
       type: 'S',
       level: 1,
       category: 'success',
       content: 'Sample created successfully.',
       title: 'Success'
     });
   } else if ($.trim(resp) == 'expiredSession') {
     window.location = 'LogOff.do';
   } else if (resp != undefined) {
     resp = $.parseJSON(resp);
     if (resp.sampleName != undefined) {
       $('#sampleTypeForm')
         .find('#sampleNameTxt')
         .next('.errEx')
         .show()
         .children('.errtooltipR')
         .text('Sample name already exists.');
     } else if (resp.createSampleFailed != undefined) {
       $('#dialogClose1').click();
       ALERTMESSAGE.open({
         type: 'M',
         level: 2,
         category: 'error',
         content: resp.createSampleFailed,
         title: 'Error'
       });
     }
   }
 },
 error: function(xhr, status, errorThrown) {
   $.fn.loadingAnimation({ display: 'close' });
   if (xhr.status == '400') {
     ALERTMESSAGE.open({
       type: 'S',
       level: 4,
       category: 'error',
       content: 'Invalid request parameters.',
       title: 'Bad request'
     });
   }
 }
});
}

function setBayesianPriorMeanValue() {
if ($('#bayesianPriorMean').attr('checked') == 'checked') {
 if ($('#baselineResponsiveChkbox').attr('checked') == 'checked') {
   $('#bayesianPriorValueObj').attr(
     'value',
     $('#bayesianSampleSizeTxt').attr('value')
   );
 } else {
   $('#bayesianPriorValueObj').attr(
     'value',
     $('#userSpecifiedTxt').attr('value')
   );
 }
} else {
 $('#bayesianPriorValueObj').attr('value', null);
}
}

function updateSampleType(checkbox) {
$('#auditedSampleId')
 .closest('div')
 .toggleClass('ser-checkbox-off ser-checkbox-on');
$('#auditedSampleId').closest('div').toggleClass('unchecked checked');

$('#sampleTypeObj').attr('value', 'MANUAL');

if ($('#normalType').attr('checked') == 'checked') {
 $('#sampleTypeObj').attr('value', 'NORMAL_DISTRIBUTION');
}
if (
 $('#bayesianType').attr('checked') == 'checked' ||
 $('#forNormaldistributionBinomialCalculator').attr('checked') == 'checked'
) {
 $('#sampleTypeObj').attr('value', 'BAYESIAN');
}
$('#auditedSampleId').attr('checked', checkbox.checked);
auditCheck = checkbox.checked;
}

var auditCheck = false;
function updateAuditSampleCheckbox(checkbox) {
$('#auditedSampleId').attr('checked', checkbox.checked);
$('#auditedSampleIdForBayesianBinomial').attr('checked', checkbox.checked);
$('#auditedSampleIdForNormalDistibution').attr('checked', checkbox.checked);
auditCheck = checkbox.checked;
}

function clearAllTextBox() {
// for title
if ($('.dialogHeading').text() == 'Sample Calculator') {
 $('.dialogHeading').text('Create Audited Sample');
} else {
 $('.dialogHeading').text('Sample Calculator');
}
$('#sampleNameTxt').val('');
$('#sampleDescriptionTxt').val('');
$('#populationDescTxt').val('');
$('#lockSampleDocumentObj').val('');
}


//Allow only numbers as text input
function isNumberKey(evt) {
var charCode = evt.which ? evt.which : event.keyCode;
if (charCode != 46 && charCode > 31 && (charCode < 48 || charCode > 57))
  return false;

return true;
}
//Allow only integer values as text input
function isIntegerKey(evt) {
var charCode = evt.which ? evt.which : event.keyCode;
if (charCode > 31 && (charCode < 48 || charCode > 57)) return false;

return true;
}

function positiveInteger(e) {
var val = e.val(),
  newVal = val.replace(/\D/g, '');
e.val(newVal);
}
$('body').on('blur', '.PosInt', function(e) {
positiveInteger($(this));
});
$('body').on('keydown', '.PosInt', function(e) {
var charCode = e.which || e.keyCode;
if (charCode == 110 || charCode == 190 || charCode == 222) return false;
});
$('body').on('keypress', '.PosInt', function(e) {
var charCode = e.which || e.keyCode;
if (
  e.shiftKey == false &&
  ((charCode >= 48 && charCode <= 57) ||
    (charCode >= 35 && charCode <= 40) ||
    charCode == 46 ||
    charCode == 8)
) {
  return true;
} else {
  return false;
}
});

function positiveIntegerDeci(e) {
var val = $.trim(e.val()),
  newVal = val.replace(/[^0-9\.]+/g, ''),
  newVal = newVal == '' ? 0 : newVal;
e.val(newVal);
}
$('body').on('blur', '.PosIntDeci', function(e) {
var i = $(this),
  ival = $.trim(i.val()),
  fval = parseFloat(ival);

if (ival == '' || !ival.match(/[0-9]/)) fval = 0;
positiveIntegerDeci(i);
i.val(fval);
});
$('body').on('keydown', '.PosIntDeci', function(e) {
var charCode = e.which || e.keyCode;
});
$('body').on('keypress', '.PosIntDeci', function(e) {
/* Allowed same keys as in PosInt with . key for decimal entries */

var charCode = e.which || e.keyCode;
if (
  e.shiftKey == false &&
  ((charCode >= 48 && charCode <= 57) ||
    (charCode >= 35 && charCode <= 40) ||
    charCode == 46 ||
    charCode == 8)
) {
  return true;
} else {
  return false;
}
});

var max_comment = 500;
var clr = 0;
function Counter(field) {
var len = 0;
len += field.value.length;
if (len > max_comment) {
  field.value = field.value.substring(
    0,
    field.value.length + max_comment - len
  );
  field.focus();
}
}

function checkChangeInput(val) {
if (document.getElementById('normalType').checked) {
  normalSampleValsChangeFlag = true;
}
if (document.getElementById('bayesianType').checked) {
  bayesianSampleValsChangeFlag = true;
}
}

function sendCalculateRequest(type) {
$.fn.loadingAnimation({ display: 'open', msg: 'Calculating...' });
sampleNameIsEmpty = false;
normalSampleValsChangeFlag = false;
bayesianSampleValsChangeFlag = false;
userSpecifiedValueApply = false;
if (document.getElementById('auditedSampleIdForBayesianBinomial')) {
  auditCheck = document.getElementById('auditedSampleIdForBayesianBinomial')
    .checked;
}
if (type == 'normal') {
  $('#sampleTypeObj').val('NORMAL_DISTRIBUTION');
} else if (type == 'baysian') {
  $('#sampleTypeObj').val('BAYESIAN');
}
if ($('#baselineResponsiveChkbox').attr('checked')) {
  userSpecifiedValueApply = false;
  $('#useBaseLineResValueObjs').attr('value', 'true');
  $('#userSpecifiedValueObjs').attr('value', 'false');
  $('#userSpecifiedTxt').attr('disabled', true);
  $('#bayesionPriorDescTxt').attr('disabled', true);
}
//$.fn.showData('GetSampleCalculator.do?action=Calculate', '#SampleCalculatorForm');
var formData = $('#SampleCalculatorForm').serialize();
$.ajax({
  type: 'POST',
  url: 'GetSampleCalculator.do?action=Calculate&' + formData,
  cache: false,
  success: function(resp) {
    $.fn.loadingAnimation({ display: 'close' });
    resp = $.parseJSON(resp);
    
    if ($('#sampleTypeObj').val() == 'NORMAL_DISTRIBUTION') {
      $('#normalContentArea input[name=totalDocsDisplay]').val(Number(resp.totalDocs).toLocaleString());
      $('#normalContentArea input[name=totalDocs]').val(resp.totalDocs);
      $('#normalContentArea input[name=confidenceLevel]').val(
        resp.confidenceLevel
      );
      $('#normalContentArea input[name=errorRate]').val(resp.errorRate);
      $('#normalContentArea input[name=variance]').val(resp.variance);
      $('#normalContentArea input[name=sampleSizeDisplay]').val(Number(resp.sampleSize).toLocaleString());
      $('#normalContentArea input[name=sampleSize]').val(resp.sampleSize);
      
    } else if ($('#sampleTypeObj').val() == 'BAYESIAN') {
      $('#bayesianContentArea input[name=totalDocsDisplay]').val(Number(resp.totalDocs).toLocaleString());
      $('#bayesianContentArea input[name=totalDocs]').val(resp.totalDocs);
      $('#bayesianContentArea input[name=bayesianConfidenceLevel]').val(
        resp.bayesianConfidenceLevel
      );
      $('#bayesianContentArea input[name=bayesianErrorRate]').val(
        resp.bayesianErrorRate
      );
      $('#bayesianContentArea input[name=minusErrorRate]').val(
        resp.minusErrorRate
      );
      $('#bayesianContentArea input[name=plusErrorRate]').val(
        resp.plusErrorRate
      );
      $('#bayesianContentArea input[name=userSpecifiedValue]').val(
        resp.userSpecifiedValue
      );
      $('#bayesianContentArea input[name=bayesianPriorDesc]').val(
        resp.bayesianPriorDesc
      );
      $('#bayesianContentArea input[name=bayesianSampleSizeDisplay]').val(
        Number(resp.bayesianSampleSize).toLocaleString()
      );
      $('#bayesianContentArea input[name=bayesianSampleSize]').val(
        resp.bayesianSampleSize
      );
    }
  },
  error: function(xhr, status, errorThrown) {
    if (xhr.status == '400') {
      ALERTMESSAGE.open({
        type: 'S',
        level: 4,
        category: 'error',
        content: 'Invalid request parameters.',
        title: 'Bad request'
      });
    }
  }
});
}

function checkManualInput(val) {
manualDocsFlag = false;
var totalCount = document.getElementById('DocumentsTotal');
if (val == '') {
  manualDocsFlag = true;
}
if (parseInt(val) <= 0) {
  manualDocsFlag = true;
}
if (parseInt(val) > parseInt(totalCount.value)) {
  manualDocsFlag = true;
}
}
function openSampleDocumentPopup(type) {
//Call on click on 'Sample' icon from datagrid results
var rnd = Math.random();
var url =
  'GetSampleCalculator.do?action=getBasicData&type=' + type + '&rnd=' + rnd;
//$.fn.showData(url, "");	//remove showData implementation. Below ajax call does same
$.ajax({
  type: 'POST',
  url: url,
  cache: false,
  success: function(resp) {
    if (resp == 'FwdToSampleCalcWindow') {
      DIALOG.open({
        type: 'SC',
        level: 1,
        title: 'Sample Calculator',
        className: 'Manual',
        loading: false,
        path:
          'SampleCalculator.jsp?resultType=' + type + '&rnd=' + Math.random()
      });
    } else {
      ALERTMESSAGE.open({
        type: 'M',
        level: 4,
        category: 'error',
        content: resp,
        title: 'Error'
      });
    }
  },
  error: function(xhr, status, errorThrown) {
    if (xhr.status == '400') {
      ALERTMESSAGE.open({
        type: 'S',
        level: 4,
        category: 'error',
        content: 'Invalid request parameters.',
        title: 'Bad request'
      });
    }
  }
});
}


var hideBayesianCheckDiv = false;
function loadSampleCalculatorResult(type) {
  sampleNameIsEmpty = false;
  if ($('#manualType').is(':checked')) {
    $('#sampleTypeObj').val('MANUAL');
    if (manualDocsFlag) {
      var totalCount;
      if (document.getElementById('DocumentsTotal') != null)
        totalCount =
          parseInt(document.getElementById('DocumentsTotal').value) + 1;

      var valsMsg =
        'Entered manual sample size should be greater than 0 or less than ' +
        totalCount +
        '. Please re-enter the new value to generate the sample.'; //'correctManualDocsSize&lessThan='+totalCount;

      ALERTMESSAGE.open({
        type: 'M',
        level: 4,
        category: 'information',
        content: valsMsg,
        title: 'Confirmation'
      });
      return;
    }
  }

  if ($('#normalType').is(':checked') && normalSampleValsChangeFlag) {
    ALERTMESSAGE.open({
      type: 'S',
      level: 4,
      category: 'information',
      content:
        'You must click "Calculate" to obtain the sample size before generating the sample.',
      title: 'Confirmation'
    });
    return;
  }
  if ($('#bayesianType').is(':checked') && bayesianSampleValsChangeFlag) {
    ALERTMESSAGE.open({
      type: 'S',
      level: 4,
      category: 'information',
      content:
        'You must click "Calculate" to obtain the sample size before generating the sample.',
      title: 'Confirmation'
    });
    return;
  }
  if ($('#bayesianType').is(':checked') && userSpecifiedValueApply) {
    ALERTMESSAGE.open({
      type: 'S',
      level: 4,
      category: 'information',
      content:
        'You must click "Calculate" to obtain the sample size before generating the sample.',
      title: 'Confirmation'
    });
    return;
  }

  if ($('#normalType').is(':checked') || $('#bayesianType').is(':checked')) {
    var errors = document.getElementById('ErrorBox');
    if (errors != null && errors.innerHTML != '') {
      ALERTMESSAGE.open({
        type: 'S',
        level: 4,
        category: 'error',
        content:
          'Please resolve the occurred errors before generating the sample.',
        title: 'Error'
      });
      return;
    }
  }

  if ($('#bayesianType').is(':checked')) {
    if ($.trim($('#bayesionPriorDescTxt').val()) == '') {
      $('#bayesionPriorDescTxt')
        .next('.errEx')
        .show()
        .children('.errtooltip')
        .text('Bayesian prior description cannot be empty.');
      //ALERTMESSAGE.open({type:'S', level:4, category:'information', content:'Bayesian prior description cannot be empty.', title:'Confirmation'});
      return;
    } else {
      $('#bayesionPriorDescTxt').next('.errEx').hide();
    }
  }

  if (
    $('#bayesianType').is(':checked') &&
    $('#userSpecifiedChkbox').is(':checked') &&
    $.trim($('#bayesionPriorDescTxt').val()) == ''
  ) {
    ALERTMESSAGE.open({
      type: 'S',
      level: 4,
      category: 'information',
      content: 'Bayesian prior description cannot be empty.',
      title: 'Confirmation'
    });
    return;
  }
  if ($('#auditedSampleId').closest('div').hasClass('ser-checkbox-on')) {
    /*if($("#auditedSampleId").is(':checked')){*/
    // for bayesian prior mean
    if ($('#baselineResponsiveChkbox').attr('checked')) {
      userSpecifiedValueApply = false;
      $('#useBaseLineResValueObjs').val('true');
      $('#userSpecifiedValueObjs').val('false');
      $('#userSpecifiedTxt').attr('disabled', true);
      $('#bayesionPriorDescTxt').attr('disabled', true);
    }
    $('#ErrorBox').html('');
    $('#lockSampleDocumentObj').val('false');
    //document.getElementById("reviewStatusRecordListID").selectedIndex = 0; // Set Review Statuses selection as 'Not Selected'
    clearAllTextBox();
    openAuditedSampleBox();
    return;
  }
  var grid = $('#grid').data('kendoGrid');
  var isFromHTMLGrid = false;
  isSimilarityCall = false;
  simColumnApplied = false;
  var url = 'GetSampleCalculator.do?action=showSample';
  if (grid != undefined && openedTabIndex == 1) {
    url =
      url +
      '&fromHTMLgrid=true&customPageSize=' +
      $('#grid').data('kendoGrid').dataSource.pageSize();
    isFromHTMLGrid = true;
  }
  dataString = $('#SampleCalculatorForm').serialize();
  $.post(url, dataString, function(data) {
    manualDocsFlag = false;
    sampleNameIsEmpty = false;
    normalSampleValsChangeFlag = false;
    bayesianSampleValsChangeFlag = false;
    userSpecifiedValueApply = false;
    if ($('#dialog1')) {
      $('#dialogClose1').click();
    }
    if (isFromHTMLGrid) {
      gridfirstLoad = true;
      requests = 1;
      $('#breadcrumb2').html(data);
      grid.dataSource.filter({});
      resizeDatagrid();
      $('#jstree').jstree('refresh');
      $('.SampleDoc').hide();
      if (searchPanelTabToggle != undefined) {
        if (openedTabIndex == undefined || openedTabIndex == null)
          openedTabIndex = 1;
        searchPanelTabToggle(openedTabIndex);
      }
      //data.indexOf("Sample/SampleDocs") > 0 ? $(".SampleDoc").hide() : $(".SampleDoc").show();
    } else {
    	angular.element('#learningCurrentModel').scope().updateShowSample(true);
    }
  });
}


//Back to result Page
function showResultPage() {
sampleNameIsEmpty = false;
isCurrentModelSample = false;
//$.fn.showData('GetSampleCalculator.do?action=restore', '');
var rnd = Math.random();
var url = 'GetSampleCalculator.do?action=restore&rnd=' + rnd;
	$.ajax({
	  type: 'POST',
	  url: url,
	  cache: false,
	  success: function(resp) {
	  	$('#SampleCalculatorList').css({ visibility: 'hidden', height: '0px' });
	  	  $('#resultFrame').css({
	  	    visibility: 'visible',
	  	    height: 'auto',
	  	    width: 'auto'
	  	  });
	  	  $('#LearningStatisticsHyperlinkResult #SampleCalcResultFrame').show();
	  	  $('#LearningStatisticsHyperlinkResult #SampleCalcResultFrame').css({
	  	    'padding-top': '15px'
	  	  });
	  	  $('#SampleCalcResultFrame').css({ visibility: 'visible', height: 'auto' });
	  	  $('.jstreeC').css({
	  	    margin: '',
	  	    'line-height': '',
	  	    visibility: 'visible',
	  	    height: finalHeight + 18
	  	  });
	  	  $('#breadcrumb2').css({
	  	    margin: '',
	  	    'line-height': '',
	  	    visibility: 'visible',
	  	    height: 'auto'
	  	  });
	  	  $('#TreeToggleBtn, #TreeToggleBtn1').css({
	  	    visibility: 'visible',
	  	    height: 'auto'
	  	  });
	
	  	  $('#ResultPanel').css({ visibility: 'visible', height: 'auto' });
	  	  if ($('#analyticsTabWrapper')) {
	  	    $('#analyticsTabWrapper, #resultsetTabWrapper, #conceptTabWrapper, #countsTabWrapper').css({
	  	      visibility: 'visible'//,
	  	      //height: finalHeight
	  	    });
	  	    //hideFacetTreeIcon();
	  	  }
	//  	  if ($('#conceptTabWrapper') && indexVariable == 2) {
	//  	    $('#conceptTabWrapper').css({ visibility: 'visible', height: finalHeight });
	//  	    //hideFacetTreeIcon();
	//  	  }
	//  	  if ($('#resultsetTabWrapper') && (indexVariable == 1 || indexVariable == 0)) {
	//  	    $('#resultsetTabWrapper').css({ visibility: 'visible', height: 'auto' });
	//  	  }
	  },
	  error: function(xhr, status, errorThrown) {
	    if (xhr.status == '400') {
	      ALERTMESSAGE.open({
	        type: 'S',
	        level: 4,
	        category: 'error',
	        content: 'Invalid request parameters.',
	        title: 'Bad request'
	      });
	    }
	  }
	});

}

//Call from Sample Stats to back on Sample List
function backToSampleSet() {
window.location = 'SearchSubset.do?subset.type=Sample_Set';
}

//Back to previous screen from Sample documents (GeneralReview.jsp);
function backToPrevScreen(btnValue, sampleKey, sampleName) {
if (btnValue.value == 'Back to Sample Statistics')
  window.location =
    'ViewSampleDocuments.do?linkType=stats&sampleKey=' +
    sampleKey +
    '&type=1&screen=SubsetList&sampleName=' +
    sampleName;
else if (btnValue.value == 'Back to Consensus Sets')
  window.location = 'SearchSubset.do?subset.type=Consensus_Set';
else window.location = 'SearchSubset.do?subset.type=Sample_Set';
}

//If sample created successfully then redirect window location to sample list page.
function redirectToSampleList() {
window.location = 'SearchSubset.do?subset.type=Sample_Set';
}