(function() {
	'use strict';	
	angular
	.module('currentModel').constant('TEN_THOUSAND', 10000);
})();