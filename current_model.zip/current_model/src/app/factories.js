(function() {
    'use strict';
    angular
        .module('currentModel')
        .factory('currentModelService', currentModelService);
    
    currentModelService.$inject = ['$http', 'responseChecker', 'THRESHOLD_MULTIPLIER'];
    /* @ngInject */
    function currentModelService($http, responseChecker, THRESHOLD_MULTIPLIER) {
        var service = {
    		getChartData:getChartData,
    		setDocumentInSession:setDocumentInSession,
    		addBucket:addBucket,
    		updateBucket:updateBucket,
    		removeBucket:removeBucket,
    		saveAllBuckets:saveAllBuckets,
    		applyLock: applyLock,
    		resetResult: resetResult
        };
        return service;
        
        function getChartData(type, runId, action, x1, x2) {
			var data = {
				action: action, 
				type:type,
				learningRunID: runId,
				lowRange:parseInt(x1 * THRESHOLD_MULTIPLIER),
				highRange:parseInt(x2 * THRESHOLD_MULTIPLIER)
			}

			return $http({
				method : 'POST',
				//url : 'current_model/src/data/histogramData1.json',
				url : 'currentModelServlet',
				data : $.param(data),
				headers : {
					'Content-Type' : 'application/x-www-form-urlencoded'
				}
			})
			.then(getChartDataComplete)
			.catch(getChartDataFailed);

			function getChartDataComplete(response) {
				responseChecker.checkSesstionTimeout(response.data);

				return response.data;
			}

			function getChartDataFailed(error) {
				console.log("getChartDataFailed Failed");
				// Check for bad request
				responseChecker.check400(error.status);

				// Check for network connectivity
				responseChecker.checkNetwork(error.status);
			}
		}
        
        function setDocumentInSession(runId, x1, x2, type) {
			var data = {
				action:'viewDocuments',
				learningRunID:runId,
				lowRange:parseInt(x1 * THRESHOLD_MULTIPLIER),
				highRange:parseInt(x2 * THRESHOLD_MULTIPLIER),
				histoType:type,
				fromAjax:true
			}

			return $http({
				method : 'POST',
				url : 'GetLearningOutput.do',
				data : $.param(data),
				headers : {
					'Content-Type' : 'application/x-www-form-urlencoded'
				}
			})
			.then(setDocumentInSessionComplete)
			.catch(setDocumentInSessionFailed);

			function setDocumentInSessionComplete(response) {
				responseChecker.checkSesstionTimeout(response.data);

				return response.data;
			}

			function setDocumentInSessionFailed(error) {
				console.log("setDocumentInSessionFailed Failed");
				// Check for bad request
				responseChecker.check400(error.status);

				// Check for network connectivity
				responseChecker.checkNetwork(error.status);
			}
		}
        
        function addBucket(runId, newBucket, type) {
			var data = {
				action:"addBucket",
				learningRunID: runId,
				bucket:JSON.stringify(newBucket),
				lowRange:newBucket.lowThreshold,
				highRange:newBucket.highThreshold,
				histoType:type
			}

			return $http({
				method : 'POST',
				url : 'currentModelServlet',
				data : $.param(data),
				headers : {
					'Content-Type' : 'application/x-www-form-urlencoded'
				}
			})
			.then(addBucketComplete)
			.catch(addBucketFailed);

			function addBucketComplete(response) {
				responseChecker.checkSesstionTimeout(response.data);

				return response.data;
			}

			function addBucketFailed(error) {
				console.log("addBucketFailed Failed");
				// Check for bad request
				responseChecker.check400(error.status);

				// Check for network connectivity
				responseChecker.checkNetwork(error.status);
			}
		}
        
        function updateBucket(runId, bucket, type) {
			var data = {
				action:"updateBucket",
				learningRunID: runId,
				bucket:JSON.stringify(bucket),
				lowRange:bucket.lowThreshold,
				highRange:bucket.highThreshold,
				histoType:type
			}

			return $http({
				method : 'POST',
				url : 'currentModelServlet',
				data : $.param(data),
				headers : {
					'Content-Type' : 'application/x-www-form-urlencoded'
				}
			})
			.then(updateBucketComplete)
			.catch(updateBucketFailed);

			function updateBucketComplete(response) {
				responseChecker.checkSesstionTimeout(response.data);

				return response.data;
			}

			function updateBucketFailed(error) {
				console.log("updateBucketFailed Failed");
				// Check for bad request
				responseChecker.check400(error.status);

				// Check for network connectivity
				responseChecker.checkNetwork(error.status);
			}
		}
        
        function removeBucket(runId, bucketId, type){
        	var data = {
				action:"removeBucket",
				bucketId:bucketId,
				learningRunID: runId,
				histoType:type
			}

			return $http({
				method : 'POST',
				url : 'currentModelServlet',
				data : $.param(data),
				headers : {
					'Content-Type' : 'application/x-www-form-urlencoded'
				}
			})
			.then(removeBucketComplete)
			.catch(removeBucketFailed);

			function removeBucketComplete(response) {
				responseChecker.checkSesstionTimeout(response.data);

				return response.data;
			}

			function removeBucketFailed(error) {
				console.log("removeBucketFailed Failed");
				// Check for bad request
				responseChecker.check400(error.status);

				// Check for network connectivity
				responseChecker.checkNetwork(error.status);
			}
        }
        
        function saveAllBuckets(runId, buckets, type){
        	var data = {
				action:"saveAllBuckets",
				buckets:JSON.stringify(buckets),
				learningRunID: runId,
				histoType: type
			}

			return $http({
				method : 'POST',
				url : 'currentModelServlet',
				data : $.param(data),
				headers : {
					'Content-Type' : 'application/x-www-form-urlencoded'
				}
			})
			.then(saveAllBucketsComplete)
			.catch(saveAllBucketsFailed);

			function saveAllBucketsComplete(response) {
				responseChecker.checkSesstionTimeout(response.data);

				return response.data;
			}

			function saveAllBucketsFailed(error) {
				console.log("saveAllBucketsFailed Failed");
				// Check for bad request
				responseChecker.check400(error.status);

				// Check for network connectivity
				responseChecker.checkNetwork(error.status);
			}
        }
        
        function applyLock(action, runId, type){
        	
        	var data = {
				action: action,
				learningRunID: runId,
				histoType: type
			}

			return $http({
				method : 'POST',
				url : 'currentModelServlet',
				data : $.param(data),
				headers : {
					'Content-Type' : 'application/x-www-form-urlencoded'
				}
			})
			.then(applyLockComplete)
			.catch(applyLockFailed);

			function applyLockComplete(response) {
				responseChecker.checkSesstionTimeout(response.data);
				if(response.data!='expiredsession'){
					return response.data;
				}
			}

			function applyLockFailed(error) {
				console.log("applyLockFailed Failed");
				// Check for bad request
				responseChecker.check400(error.status);

				// Check for network connectivity
				responseChecker.checkNetwork(error.status);
			}
        }
        
        function resetResult(){
        	var data = {
				action: 'restore',
				searchType:7,
				rnd: Math.random()
			}
        	
			return $http({
				method : 'POST',
				url : 'GetSampleCalculator.do',
				data : $.param(data),
				headers : {
					'Content-Type' : 'application/x-www-form-urlencoded'
				}
			})
			.then(resetResultComplete)
			.catch(resetResultFailed);

			function resetResultComplete(response) {
				responseChecker.checkSesstionTimeout(response.data);
				if(response.data!='expiredsession'){
					return response.data;
				}
			}

			function resetResultFailed(error) {
				console.log("resetResultFailed Failed");
				// Check for bad request
				responseChecker.check400(error.status);

				// Check for network connectivity
				responseChecker.checkNetwork(error.status);
			}
        }
    }
})();