(function() {
	angular
		.module('currentModel')
		.directive('chartArea', chartArea);

	/* @ngInject */
	chartArea.$inject = [];
	function chartArea() {
		
		var directive = {
			link:link,
			controller: chartAreaController,
			bindToController: true,
			controllerAs: 'vm',
			scope: {
				chartData: '=',
				chartSettings: '=',
				showChartArea: '=',
				chartDataChanged:'=',
				setMinTick: '&setMinTick',
				setMaxTick: '&setMaxTick',
				setTick: '&setTick',
				displayChartLoader: '&displayChartLoader'
			},
			replace:true,
			templateUrl: 'current_model/src/app/chart_area/chart-area.html'
		}
		
		return directive;
		
		function link(scope, element, attrs) {
        	
        }
	}

	/* @ngInject */
	chartAreaController.$inject = ['$rootScope', '$window', '$scope', 'currentModelService', 'THRESHOLD_MULTIPLIER'];
	function chartAreaController($rootScope, $window, $scope, currentModelService, THRESHOLD_MULTIPLIER) {
		var vm = this;
		vm.resizeMode = "FixedResizer";
		vm.showIcons = false;
		vm.zoomXPos = 0;
		vm.docXPos = 0;
		vm.oneBarSelected = '';
		vm.screenData = setScreenHeight();
		vm.dummy = true;
		
		vm.zoomIn = function(x1, x2){
			vm.displayChartLoader({val:true, msg:"Zooming In"});
			currentModelService.getChartData(vm.chartData.name, vm.chartData.runID, 'zoomCurrentModel', x1, x2)
				.then(function(data){
					vm.displayChartLoader({val:false, msg:""});
					vm.chartData = data;
					vm.showIcons = false;
					vm.chartDataChanged = true;
				});
		}
		
		vm.zoomOut = function(){
			vm.displayChartLoader({val:true, msg:"Zooming Out"});
			var x1 = 0, x2 = 1;
			if(vm.chartData.name == "Responsive"){
				x1 = 0;
				x2 = 0.5;
			} else if(vm.chartData.name == "NonResponsive"){
				x1 = 0.5;
				x2 = 1;
			}
			currentModelService.getChartData(vm.chartData.name, vm.chartData.runID, 'zoomCurrentModel', x1, x2)
				.then(function(data){
					vm.displayChartLoader({val:false, msg:""});
					vm.chartData = data;
					vm.showIcons = false;
					vm.chartDataChanged = true;
				});
		}

		vm.showDocuments = function(x1, x2){
			$rootScope.$emit('SHOW_DOCUMENTS', x1, x2);
			currentModelService.setDocumentInSession(vm.chartData.runID, x1, x2, vm.chartData.name)
				.then(function(response){
					if(response == "success"){
						$rootScope.$emit('UPDATE_DOCUMENT_GRID');
					}
				});
			//vm.showChartArea = false;
		}
		
		vm.setBucket = function(b){
			$("#dummyBtn").click();
			//console.log("updated buckets ",vm.chartData.buckets);
		}

		function setScreenHeight(){
			$(".h_acc_c").width($(".h_acc_s.expanded").width() - 30);
			return {
				width:$(".dashboard-panel").width() - (280 + vm.chartSettings.chartMargin.right + vm.chartSettings.chartMargin.left),
				height:$(".dashboard-panel").height() - (80 + vm.chartSettings.chartMargin.top + vm.chartSettings.chartMargin.bottom),
				margin:{
					top:vm.chartSettings.chartMargin.top,
					right:vm.chartSettings.chartMargin.right,
					bottom:vm.chartSettings.chartMargin.bottom,
					left:vm.chartSettings.chartMargin.left}
			}
		}
		
		/**********************/
		
		$scope.$watch('vm.chartDataChanged', function (newValue, oldValue) {
			//console.log("vm.chartDataChanged",vm.chartDataChanged);
			if(!vm.chartDataChanged || vm.chartData == undefined) return;
			vm.chartDataChanged = false;
			var totalBars = vm.chartData.bargraph.bars.length;
			var chartLowThreshold = vm.chartData.bargraph.bars[0].lowThreshold/THRESHOLD_MULTIPLIER;
			var chartHighThreshold = vm.chartData.bargraph.bars[totalBars - 1].highThreshold/THRESHOLD_MULTIPLIER;
			
			//console.log("low:"+chartLowThreshold+", high:"+chartHighThreshold);
			d3.select("#histogram").selectAll("svg").remove();
			hideAllIcons();
			
			//var x = d3.scale.linear().range([0, vm.screenData.width]);
			var x = d3.scale.ordinal()
			    .domain(getTickValues(vm.chartData.bargraph.bars))
			    .rangePoints([0, vm.screenData.width], 0);
			var y = d3.scale.linear().range([vm.screenData.height, 0]);
			var xAxis = d3.svg.axis().scale(x).orient("bottom").tickValues(getTickValues(vm.chartData.bargraph.bars)).tickFormat(d3.format());
			var yAxis = d3.svg.axis().scale(y).orient("left");
			
			vm.xAxisPlotArr = getTickValues(vm.chartData.bargraph.bars);//xAxis.scale().ticks(xAxis.ticks()[0]);
			//console.log(vm.xAxisPlotArr[0]);
			
			vm.setMinTick({val: vm.xAxisPlotArr[0]});
			vm.setMaxTick({val: vm.xAxisPlotArr[vm.xAxisPlotArr.length-1]});
			vm.setTick({val: vm.xAxisPlotArr[1] - vm.xAxisPlotArr[0]});
			vm.tickSize = vm.xAxisPlotArr[1] - vm.xAxisPlotArr[0];
			//console.log("vm.tickSize: "+vm.tickSize);
			//$scope.$apply();
			var svg = d3.select("#histogram").append("svg")
			    .attr("width", vm.screenData.width + vm.screenData.margin.left + vm.screenData.margin.right)
			    .attr("height", vm.screenData.height + vm.screenData.margin.top + vm.screenData.margin.bottom)
			  	.append("g")
			    .attr("transform", "translate(" + vm.screenData.margin.left + "," + vm.screenData.margin.top + ")");
			var brush = d3.svg.brush()
				.x(x)
				.on("brush", brushmove)
				.on("brushend", brushend);
			var data = vm.chartData.bargraph.bars;
			var buckets = vm.chartData.buckets;
			
			
			var maxDocCount = d3.max(data, function(d) {return parseInt(d.docCount);});
			var maxDocRatio = maxDocCount * 5 / 100;
			//x.domain([chartLowThreshold, chartHighThreshold]);
			y.domain([0, maxDocCount + maxDocRatio]);
			
			svg.append("g")
				.attr("class", "x axis")
				.call(xAxis)
				.attr("transform", "translate(0," + vm.screenData.height + ")")
				.attr("id", "xAxisLine");
		
			svg.append("g")
				.attr("class", "y axis")
				.call(yAxis)
				.attr("id", "yAxisLine");
			
			
			tip = d3.tip()
				.attr('class', 'd3-tip')
				.offset([-10, 0])
				.html(function(d) {
					return "<strong>Documents: </strong> <span>" + d.docCount + "</span>";
				});
			
			svg.call(tip);

			svg.append("defs").append("clipPath")
				.attr("id", "clip")
				.append("rect")
				.attr("width", vm.screenData.width)
				.attr("height", vm.screenData.height + 20);
			
			svg.append("g")
				.attr("class", "brush")
				.call(brush)
				.selectAll("rect")
				.attr("height", vm.screenData.height);
				
			bars = svg.selectAll(".bar")
				.data(data)
				.enter().append("rect")
				.attr("class", "bar")
				.style("fill", vm.chartSettings.barColor)
				.attr("x", function(d) { return x(d.lowThreshold/THRESHOLD_MULTIPLIER);})
//				.attr("width", function(d) { 
//					return x((data[0].lowThreshold + d.highThreshold - d.lowThreshold)/THRESHOLD_MULTIPLIER);
//				})
				.attr("width", vm.screenData.width/data.length)
				.attr("y", vm.screenData.height)
				//.attr("rx", 10)
				//.attr("ry", 10)
				.attr("height", 0)
				.on('mouseover', tip.show)
				.on('mouseout', tip.hide)
				.on("mousedown", brushing)
				.transition()
				.duration(200)
				.delay(function (d, i) {
					return i * 50;
				})
				.attr("y", function(d) { return y(d.docCount); })
				.attr("height", function(d) {return vm.screenData.height - y(d.docCount);});
				
			
			function brushing(){
				brush_elm = svg.select(".brush").node();
				new_click_event = new Event('mousedown');
				new_click_event.pageX = d3.event.pageX;
				new_click_event.clientX = d3.event.clientX;
				new_click_event.pageY = d3.event.pageY;
				new_click_event.clientY = d3.event.clientY;
				brush_elm.dispatchEvent(new_click_event);
			}
			
			
			function brushmove() {

			}

			function brushend() {
				var extentArr0 = getArrayExtentValue(brush.extent()[0]);
				var extentArr1 = getArrayExtentValue(brush.extent()[1]);
				var extent0 = extentArr0[0];
				var extent1 = extentArr1[0];
				vm.selectedExtent1 = extentArr0[1];
				vm.selectedExtent2 = extentArr1[1];
				
				d3.select(this).transition().call(brush.extent([extent0, extent1]));
				if(extent0 != extent1){
					showAllIcons(extent0, extent1, vm.selectedExtent1, vm.selectedExtent2);
				}
				else {
					hideAllIcons();
				}
				$scope.$apply();
			}
			

			function getArrayExtentValue(b) {
			    for(var i=0; i<vm.xAxisPlotArr.length; i++) {
			    	if(b < x(vm.xAxisPlotArr[i])) {
				    	if(b < (x(vm.xAxisPlotArr[i-1]) + x(vm.xAxisPlotArr[i]))/2) {
				    		return [x(vm.xAxisPlotArr[i-1]), vm.xAxisPlotArr[i-1]];
				    	}
				    	else {
				    		return [x(vm.xAxisPlotArr[i]), vm.xAxisPlotArr[i]];
				    	}
			    	}
			    }
			}
			
			vm.getDomain = function(b){
				return x(b.val);
			}
			
			
			function showAllIcons(x1, x2, sx1, sx2){
				vm.showIcons = true;
				var index1 = vm.xAxisPlotArr.indexOf(sx1);
				var index2 = vm.xAxisPlotArr.indexOf(sx2);
				if(index2 - index1 != 1){
					vm.oneBarSelected = '';
					vm.zoomXPos = x1+51;
					vm.docXPos = x2+6;
				} else {
					vm.oneBarSelected = 'one-bar-selected';
					vm.zoomXPos = x1+42;
					vm.docXPos = x1+57;
				}
				//console.log(x1, x2, sx1, sx2);
				$('svg').mouseout();
			}
			
			function hideAllIcons(){
				vm.showIcons = false;
				$('svg').mouseout();
			}
		});
		
		function getTickValues1(x1, x2, l){
			var diff = (x2 - x1) / l;
			var arr = [];
			for(var i=0; i<l; i++){
				arr.push(x1+(diff*i));
			}
			//console.log("arr: "+arr);
			return arr;
		}
		
		function getTickValues(chartData){
			var arr = [];
			for(var i=0; i<chartData.length; i++){
				arr.push(chartData[i].lowThreshold/THRESHOLD_MULTIPLIER);
			}
			arr.push(chartData[chartData.length-1].highThreshold/THRESHOLD_MULTIPLIER);
			
			return arr;
		}
		
		
		/**********************/

		angular.element($window).bind('resize', function() {
			vm.chartDataChanged = true;
			vm.screenData = setScreenHeight();
			$scope.$apply();
			$('svg').mouseout();
		});
	}
})();
