(function() {
    'use strict';
    angular
        .module('currentModel')
        .directive('tableResize', tableResize);
    tableResize.$inject = ['$timeout'];
    
    function tableResize($timeout) {
	    var mode;
	    var columns = null;
	    var table = null;
	    var steps = [];
	    var lastObj;
	
	    function link(scope, element, attr) {
	    	scope.$watch(function() {
	    		//console.log("not changed");
				return scope.vm.bucket;
			}, function(newValue, oldValue) {
	    		if(newValue == undefined) return;
		        // Set global reference to table
	    		table = element;
	    		steps.length = 0;
		        
		        $timeout(function(){
		        	for(var i=0; i<=20; i++){
		        		steps.push(0 + (scope.vm.tickSize * i));
		        	}
			        $(table).find("tr:last-child").find("th").each(function(){
			        	//console.log("called one time");
			        	if($(this).index() < $(table).find("tr:last-child").find("th").size() - 1){
			        		initHandle(this);
			        	}
			        })
		        }, 1000);
		
		
			    function initHandle(column) {
			        // Prepend a new handle div to the column
			        var handle = $('<div>', {
			            class: 'handle'
			        });
			        $(column).prepend(handle);
			
			        // Bind mousedown, mousemove & mouseup events
			        bindEventToHandle(table, handle, column);
			    }
			
			    function bindEventToHandle(table, handle, column) {
			        // This event starts the dragging
			        $(handle).mousedown(function(event) {
			        	//console.log("inside mousedown");
			          	var orgHW = [];
			          	$(table).find("tr:last-child").find("th").each(function(){
			          		orgHW.push($(this).width());
			          	});
			          	
			
			            // Change css styles for the handle
			            $(handle).addClass('active');
			
			            // Show the resize cursor globally
			            $('body').addClass('table-resize');
			
			            // Get mouse and column origin measurements
			            var orgX = event.clientX - $(table).position().left;
			            var orgWidth = $(column).width();
			            var nxtColWidth = $(column).next().width();
			
			            // On every mouse move, calculate the new width
			            $(window).mousemove(
			            	calculateWidthEvent(column, orgX, orgWidth, orgHW, nxtColWidth)
			        	);
			
			            // Stop dragging as soon as the mouse is released
			            $(window).one('mouseup', unbindEvent(handle))
			
			        })
			    }
			
			    function calculateWidthEvent(column, orgX, orgWidth, orgHW, nxtColWidth) {
			    	//console.log(orgX, orgWidth, orgHW, nxtColWidth);
			        return function(event) {
			        	//column -> active column
			        	//orgX -> new mouse position
			        	//orgWidth -> original column width as the column's width is not changed
			        	//nxtColWidth -> next column width which is not yet changed
			        	//console.log(orgX, orgWidth, nxtColWidth);
			        	//console.log(scope.vm.ticks);
			        	var index = $(column).index();	//getting current col index
			        	var ticks = scope.vm.ticks;
			        	var newX = event.clientX - ($(table).position().left + 30);
			        	var newTick;
			        	for(var i=0; i<ticks.length; i++) {
					    	if(newX < scope.vm.getDomain({val: ticks[i]})) {
						    	if(newX < (scope.vm.getDomain({val: ticks[i-1]}) + scope.vm.getDomain({val: ticks[i]}))/2) {
						    		newTick = ticks[i-1];
						    	}
						    	else {
						    		newTick = ticks[i];
						    	}
						    	break;
					    	}
					    }
			        	//console.log("newTick", newTick);
			        	var bucket = scope.vm.bucket;
			        	for(var i=0; i<=bucket.length; i++){
			        		if(i == index) {
			        			if(bucket[i].lowThreshold/10000 < newTick && bucket[i+1].highThreshold/10000 > newTick){
				        			bucket[i].highThreshold = newTick*10000;
				        			bucket[i+1].lowThreshold = newTick*10000;
			        			}
			        			break;
			        		}
			        	}
			        	scope.vm.setBucket();
			            lastObj = event.target;
			        }
			    }
			
			    function unbindEvent(handle) {
			        // Event called at end of drag
			        return function() {
			        	
			            $(handle).removeClass('active');
			            $(window).unbind('mousemove');
			            $('body').removeClass('table-resize');
			            $('svg').mouseout();
			        }
			    }
	    	});
	    }
	    
	    var directive = {
	        bindToController: true,
	        controller: tableResizeController,
	        controllerAs: 'vm',
	        link: link,
	        restrict: 'A',
	        scope: {
	        	ticks:'=',
	        	tickSize: '=',
	        	bucket: '=',
	        	screenData: '=',
        		setBucket: '&',
        		getDomain: '&',
	        }
	    };
	    return directive;
    }
    
    function tableResizeController() {
    	var vm = this;
    }
})();
