(function() {
	angular.module('currentModel')
		.controller('mainController', mainController);
	
	mainController.$inject = ['$rootScope', '$scope', '$window'];

	function mainController($rootScope, $scope, $window) {
		$scope.isWrapText = isWrapText;
		$scope.gadgetData = {"barColor":"#5493f8","chartMargin":{"top":20,"right":40,"bottom":40,"left":40}};
		$scope.showChartArea = true;
		$scope.learningRunId = learningRunId;
		$scope.showSample = false;
		calculatePanelHeight();
		//console.log($scope.panelHeight);
		
		$rootScope.$on('SHOW_DOCUMENTS', function(e){
			console.log("Inside show doc controller");
			$scope.showChartArea = false;
    	});
		
		function calculatePanelHeight() {
			$scope.panelHeight = $window.innerHeight - 100;
			//console.log($scope.panelHeight);
        }

        function debounce(func, wait, immediate) {
        	var timeout;
        	return function() {
        		var context = this, args = arguments;
        		var later = function() {
        			timeout = null;
        			if (!immediate) func.apply(context, args);
        		};
        		var callNow = immediate && !timeout;
        		clearTimeout(timeout);
        		timeout = setTimeout(later, wait);
        		if (callNow) func.apply(context, args);
        	};
        };
        
        $scope.updateShowSample = function(val){
        	console.log("showsampleupdated", val);
        	$scope.showSample = val;
        	if(val){
        		$scope.$apply();
        	}
        }
        
        
        var debouncer = debounce(function() {
        	calculatePanelHeight();
        }, 50);

        angular.element($window).bind('resize', function() {
        	debouncer();
        });
	}
})();